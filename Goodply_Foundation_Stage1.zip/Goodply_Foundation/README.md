# Goodply — Foundation build

This is the first staged reconstruction of Goodply from the supplied AI Tool documents and master specification. It establishes the repository foundation; it is **not** the complete Goodply product and does not claim the 15 modules are finished.

## Stack selected from the supplied materials
- Web: Next.js 16.4.5 / React 19 / TypeScript
- API: Python 3.12 / FastAPI
- Database: PostgreSQL 16 with SQLAlchemy async
- Cache/queue foundation: Redis 7

## Contents
- `backend/`: FastAPI app, environment configuration, lazy async database engine, health endpoints and tests.
- `frontend/`: Next.js foundation shell, typed API client and system status page.
- `docker-compose.yml`: local PostgreSQL, Redis, API and web services.
- `reference_material/`: one canonical copy of each unique supplied source document.
- `docs/`: source inventory and staged build/acceptance plan.

## Local start
1. Install Docker Engine / Docker Desktop and Docker Compose.
2. Copy `.env.example` to `.env` and replace `POSTGRES_PASSWORD` with a long random value using letters, numbers and underscores (the local compose DSN is assembled from this value). Do not commit `.env`.
3. Run `docker compose up --build` from this folder.
4. Open `http://localhost:3000`; API docs are at `http://localhost:8000/api/v1/docs`.

The API readiness endpoint is `GET http://localhost:8000/api/v1/health/ready`. It reports not-ready until PostgreSQL and Redis are reachable.

## Backend tests
From `backend/`:

```bash
python -m venv .venv
. .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -e '.[dev]'
pytest -q
```

## Important current limitations
- Identity, tenant RLS, core business schemas, Alembic history, AI providers, integrations, billing and business workflows are not yet wired into this foundation.
- PostgreSQL and Redis services are defined, but this stage intentionally does not create business tables or apply unverified migration excerpts.
- The frontend status page calls a real readiness endpoint; the home page is a foundation shell, not a claim that the product modules are functional.
- Production deployment, secret management, backups, monitoring, store publication and external provider credentials are not configured here.

See `docs/BUILD_SEQUENCE.md` for the acceptance gates for the next stages.
