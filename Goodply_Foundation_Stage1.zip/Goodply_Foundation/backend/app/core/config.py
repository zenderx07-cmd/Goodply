from functools import lru_cache
from typing import Literal

from pydantic import Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Environment-backed configuration. Secrets are never given production defaults."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
        extra="ignore",
    )

    PROJECT_NAME: str = "Goodply"
    ENVIRONMENT: Literal["development", "test", "staging", "production"] = "development"
    API_V1_STR: str = "/api/v1"
    BACKEND_CORS_ORIGINS: str = "http://localhost:3000"
    DATABASE_URL: str | None = None
    REDIS_URL: str | None = None
    SECRET_KEY: SecretStr | None = None
    LOG_LEVEL: str = "INFO"
    HEALTH_CHECK_TIMEOUT_SECONDS: float = Field(default=2.0, gt=0, le=10)

    @property
    def cors_origins(self) -> list[str]:
        return [origin.strip() for origin in self.BACKEND_CORS_ORIGINS.split(",") if origin.strip()]

    def validate_production_configuration(self) -> None:
        missing: list[str] = []
        if not self.DATABASE_URL:
            missing.append("DATABASE_URL")
        if not self.REDIS_URL:
            missing.append("REDIS_URL")
        if self.SECRET_KEY is None or len(self.SECRET_KEY.get_secret_value()) < 32:
            missing.append("SECRET_KEY (at least 32 characters)")
        if missing:
            raise RuntimeError("Missing or invalid production configuration: " + ", ".join(missing))


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
