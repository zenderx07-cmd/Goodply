from collections.abc import AsyncIterator

from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker, create_async_engine

from app.core.config import settings

_engine: AsyncEngine | None = None
_session_factory: async_sessionmaker[AsyncSession] | None = None


def get_engine() -> AsyncEngine:
    """Create the async PostgreSQL engine lazily, so health/liveness can boot without DB access."""
    global _engine, _session_factory
    if _engine is None:
        if not settings.DATABASE_URL:
            raise RuntimeError("DATABASE_URL is not configured")
        if not settings.DATABASE_URL.startswith("postgresql+asyncpg://"):
            raise RuntimeError("DATABASE_URL must use the postgresql+asyncpg:// driver")
        _engine = create_async_engine(
            settings.DATABASE_URL,
            pool_pre_ping=True,
            pool_size=5,
            max_overflow=10,
            pool_recycle=1800,
        )
        _session_factory = async_sessionmaker(_engine, expire_on_commit=False, autoflush=False)
    return _engine


async def get_db_session() -> AsyncIterator[AsyncSession]:
    """Request-scoped database session; callers own explicit transaction boundaries."""
    get_engine()
    if _session_factory is None:  # Defensive guard for static analysis and unusual reloads.
        raise RuntimeError("Database session factory was not initialized")
    async with _session_factory() as session:
        yield session


async def dispose_database() -> None:
    global _engine, _session_factory
    if _engine is not None:
        await _engine.dispose()
    _engine = None
    _session_factory = None
