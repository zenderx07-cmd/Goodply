import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Goodply | Business Management Platform',
  description: 'One connected workspace for managing and understanding your business.',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
