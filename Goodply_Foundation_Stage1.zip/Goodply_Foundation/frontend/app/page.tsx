import Link from 'next/link';

const plannedAreas = [
  'Customers and conversations',
  'Reviews and reputation',
  'Support and operations',
  'Sales and marketing',
  'People and inventory',
  'Analytics and AI assistance',
];

export default function HomePage() {
  return (
    <main className="min-h-screen bg-slate-50 px-6 py-12 text-slate-900">
      <div className="mx-auto max-w-5xl">
        <header className="flex items-center justify-between border-b border-slate-200 pb-6">
          <div className="text-2xl font-bold tracking-tight">goodply<span className="text-emerald-600">.</span></div>
          <Link href="/status" className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-medium hover:bg-white">
            System status
          </Link>
        </header>
        <section className="py-20">
          <p className="mb-4 text-sm font-semibold uppercase tracking-[0.18em] text-emerald-700">Business, connected</p>
          <h1 className="max-w-3xl text-4xl font-semibold tracking-tight sm:text-6xl">
            One workspace to run and understand your business.
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-600">
            Goodply is being assembled as a connected business platform. The foundation is being established before business workflows are switched on.
          </p>
          <div className="mt-12 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {plannedAreas.map((area) => (
              <div key={area} className="rounded-xl border border-slate-200 bg-white p-5 text-sm font-medium shadow-sm">
                {area}
              </div>
            ))}
          </div>
          <p className="mt-8 text-sm text-slate-500">This foundation screen does not represent completed or connected business modules.</p>
        </section>
      </div>
    </main>
  );
}
