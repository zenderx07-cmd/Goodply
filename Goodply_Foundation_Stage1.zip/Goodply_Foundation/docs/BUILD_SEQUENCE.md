# Goodply staged build and acceptance plan

Framework note: the supplied frontend snippets reference Next.js 14.2.3 / React 18. This foundation is upgraded to Next.js 16.4.5 / React 19: the official support policy currently lists 16.x as Active LTS and 14.x as unsupported. The exact frontend dependency versions will be locked after dependency installation and a production build.

## Stage 1 — Foundation (this package)
- Establish a reproducible repository layout for Next.js and FastAPI.
- Establish environment-based configuration and safe local secret handling.
- Provide PostgreSQL/Redis development services through Docker Compose.
- Add liveness and dependency-readiness endpoints.
- Add a small frontend shell and a live API status view.
- Preserve the unique supplied source documents for controlled reconciliation.

Acceptance: Python modules compile; health tests pass; frontend strict type-check/build passes when Node dependencies are installed; Docker Compose configuration validates; no business module is represented as complete at this stage.

## Stage 2 — Identity and tenant foundation
- Reconcile migrations 001–012 and establish a single Alembic history.
- Implement organization membership, branches, users, invitations, sessions, refresh rotation and recovery.
- Implement role/permission checks and transaction-safe tenant context.
- Add PostgreSQL RLS policies plus cross-tenant foreign-key tests.

## Stage 3 — Shared application shell
- Navigation, organization/branch switcher, user settings, notifications, search and audit trail.
- Connect the frontend API client to real authenticated endpoints.

## Stage 4 — Business modules
Build each module behind shared identity, tenant, permissions, audit and event infrastructure. Each module requires schema, service, API, UI, authorization and tests before being considered complete.

## Stage 5 — AI, automation and integrations
Implement real provider clients, quota reservation/settlement, citations, tenant-aware retrieval, automation execution, provider OAuth and signed webhooks.

## Stage 6 — Global operations and SaaS administration
Support, incident management, subscription ledger, entitlements, monitoring, backup/restore and release controls.

## Stage 7 — Mobile and release engineering
Choose the mobile approach after the current frontend is reconciled. Add Android/iOS builds, end-to-end tests, signing, store metadata and deployment runbooks.

## Verification policy
Every stage records commands executed, results, failures, skipped checks and external dependencies. Static compilation is not described as runtime integration testing; tests using mocks are not described as live-provider tests; local tests are not described as production security certification.
