# Goodply — staged application build

Goodply is being reconstructed from the supplied AI Tool frontend/backend documents and the master product specification. This repository is the working application codebase. It is being built in stages; it is **not yet the complete Goodply product** and no claim is made that all 15 business modules are implemented.

## Stack

- Web application: Next.js 16 / React 19 / TypeScript
- API: Python 3.12 / FastAPI
- Persistence: PostgreSQL 16 / SQLAlchemy async / Alembic
- Rate limiting and future background work: Redis 7
- Local orchestration: Docker Compose

## Repository structure

- `frontend/` — login, organization registration, authenticated workspace and system status UI.
- `backend/app/` — API, environment configuration, database/session handling, tenant context, authentication, access control and organization endpoints.
- `backend/migrations/` — executable Alembic chain for revisions 001–005.
- `database/init/` — PostgreSQL first-initialization script creating a restricted non-superuser application role.
- `backend/tests/` — unit and API-contract tests currently runnable without live infrastructure.
- `reference_material/` — canonical unique copies of the supplied product specification and AI Tool implementation documents.
- `docs/` — source inventory, migration reconciliation, build sequence and verification evidence.

## Local run

1. Install Docker Engine/Desktop with Docker Compose v2.
2. Copy `.env.example` to `.env`; set both `POSTGRES_PASSWORD` (migration/admin role) and `POSTGRES_APP_PASSWORD` (restricted runtime role) to different strong values containing letters, numbers and underscores. Do not commit `.env`.
3. Run `docker compose up --build` from this folder. On a fresh PostgreSQL volume, the init script creates `goodply_app` as a non-superuser with no `BYPASSRLS`; migrations run with the privileged `goodply` account, then the API starts with the restricted app account. The migration URL is removed from the API process environment after startup.
4. Open the web app at `http://localhost:3000` and API docs at `http://localhost:8000/api/v1/docs`.

The backend container waits for healthy PostgreSQL and Redis, applies the current Alembic migrations with the dedicated migrator, tightens read-only locator/catalog, append-only audit-log and migration-metadata grants, then starts FastAPI with the restricted runtime account. FastAPI startup verifies that the connected role is the configured application role and refuses to run if it is a superuser or has `BYPASSRLS`. The database and Redis data use named local volumes. PostgreSQL init scripts run only when the data volume is first initialized. If you previously started an older Stage 1 database volume, the new migration and application roles will not be created automatically; for a disposable local database, run `docker compose down -v` before `docker compose up --build` (this permanently deletes all data in those local volumes), or provision the roles/schema grants manually.

## Implemented API surface in this stage

- `POST /api/v1/auth/register` — create the first user, organization, Head Office branch, owner membership, default roles and initial session.
- `POST /api/v1/auth/login`, `POST /api/v1/auth/refresh`, `POST /api/v1/auth/logout`, `GET /api/v1/auth/me`.
- `POST /api/v1/auth/invitations/accept` — one-time invitation acceptance.
- `GET /api/v1/organizations/current`, `GET/POST /api/v1/branches`.
- `GET /api/v1/members`, `POST /api/v1/organizations/current/invitations`.
- `GET/POST /api/v1/roles`, `PUT /api/v1/roles/{role_id}`, `PUT /api/v1/members/{membership_id}/roles`.
- `GET /api/v1/health/live`, `GET /api/v1/health/ready`.

Authentication uses Argon2 password hashes, short-lived signed access tokens in HTTP-only cookies, rotating opaque refresh tokens stored as hashes, refresh-family reuse detection, and double-submit CSRF for cookie-authenticated write requests. Redis-backed rate limiting applies to registration and login when Redis is configured. Organization and tenant-scoped rows use PostgreSQL row-level security policies; the session layer reapplies tenant/user context for each transaction. The runtime database role is a separate non-superuser and has no `BYPASSRLS`; the organization locator and permission catalog are read-only, the user identity directory is accessible only through an exact-email lookup function that returns an account ID rather than directory rows, and runtime audit-log access is append-only. At startup, the API verifies the configured runtime database role is not superuser and does not have `BYPASSRLS`.

## Backend tests

From `backend/`:

```bash
python -m venv .venv
. .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -e '.[dev]'
pytest -q
```

The current offline SQL preview for revisions 001–005 is in `docs/migration_preview_001_005.sql`. It is a generated preview, not evidence of a successful live migration. Offline migration SQL can be regenerated with:

```bash
alembic upgrade head --sql > migration-preview.sql
```

## Stage 2 limitations and release gates

- The current environment verification did not have Docker, PostgreSQL, Redis, `asyncpg`, or the `redis` Python package installed. The live database migration, runtime-role privileges, RLS behavior, refresh-rotation concurrency, and Redis rate-limit paths have **not** been integration-tested here.
- The frontend package installation timed out in this environment. The Next.js type-check and production build remain unverified. Run `npm install`, `npm run typecheck`, and `npm run build` in `frontend/` or use the frontend Docker build.
- Invitation delivery is not connected to an email provider yet. The API returns a one-time invitation token to an authorized inviter; share it securely during development only.
- Email verification, password reset, MFA/passkeys, self-service membership switching, branch-scope editing, department-scope administration and a full audit viewer remain future work.
- The owner role is protected against editing, and the last active owner cannot be downgraded. Additional administrative safeguards and full integration tests are still required.
- Migrations 001–005 establish the base chain. Supplied later migrations 006–011 still require controlled reconciliation; supplied migration 012 is superseded by the stronger refresh-token table in 004 and must not be applied verbatim.
- AI providers, external integrations, billing, platform/global admin, business workflows and the 15 product modules are not complete in this stage.
- Production deployment, managed secret storage, backup/restore, observability, security testing, performance/load testing, mobile builds and app-store publication are not configured.

See `docs/BUILD_SEQUENCE.md`, `docs/MIGRATION_RECONCILIATION.md` and `docs/VERIFICATION_LOG.md` for scope and evidence.
