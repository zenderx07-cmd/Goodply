'use client';

import Link from 'next/link';
import { type FormEvent, useState } from 'react';
import { useRouter } from 'next/navigation';
import { ApiError, apiRequest } from '@/lib/api-client';

type AuthResponse = {
  user: { id: string; email: string; full_name: string };
  organization: { id: string; name: string; slug: string; status: string; tier: string };
  roles: string[];
  permissions: string[];
};

export default function RegisterPage() {
  const router = useRouter();
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [organizationName, setOrganizationName] = useState('');
  const [organizationSlug, setOrganizationSlug] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  function updateOrganizationName(value: string) {
    setOrganizationName(value);
    setOrganizationSlug(value.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 63));
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      await apiRequest<AuthResponse>('/auth/register', {
        method: 'POST',
        body: JSON.stringify({ full_name: fullName, email, password, organization_name: organizationName, organization_slug: organizationSlug }),
      });
      router.replace('/workspace');
    } catch (cause) {
      setError(cause instanceof ApiError ? cause.message : 'Unable to create your workspace. Please try again.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-50 px-5 py-12 text-slate-900">
      <section className="w-full max-w-lg rounded-2xl border border-slate-200 bg-white p-8 shadow-sm">
        <Link href="/" className="text-2xl font-bold tracking-tight">goodply<span className="text-emerald-600">.</span></Link>
        <h1 className="mt-8 text-2xl font-semibold">Create your Goodply workspace</h1>
        <p className="mt-2 text-sm text-slate-600">This creates your organization and makes you its first owner.</p>
        <form onSubmit={handleSubmit} className="mt-7 space-y-4">
          <label className="block text-sm font-medium">Your full name
            <input required minLength={2} maxLength={120} autoComplete="name" value={fullName} onChange={(event) => setFullName(event.target.value)} className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2.5 outline-none focus:border-emerald-600 focus:ring-2 focus:ring-emerald-100" />
          </label>
          <label className="block text-sm font-medium">Work email
            <input required type="email" autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2.5 outline-none focus:border-emerald-600 focus:ring-2 focus:ring-emerald-100" />
          </label>
          <label className="block text-sm font-medium">Password <span className="font-normal text-slate-500">(12 characters minimum)</span>
            <input required type="password" minLength={12} maxLength={128} autoComplete="new-password" value={password} onChange={(event) => setPassword(event.target.value)} className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2.5 outline-none focus:border-emerald-600 focus:ring-2 focus:ring-emerald-100" />
          </label>
          <label className="block text-sm font-medium">Organization name
            <input required minLength={2} maxLength={200} value={organizationName} onChange={(event) => updateOrganizationName(event.target.value)} className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2.5 outline-none focus:border-emerald-600 focus:ring-2 focus:ring-emerald-100" placeholder="Example Group" />
          </label>
          <label className="block text-sm font-medium">Organization address
            <input required minLength={3} maxLength={63} value={organizationSlug} onChange={(event) => setOrganizationSlug(event.target.value.toLowerCase())} className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2.5 outline-none focus:border-emerald-600 focus:ring-2 focus:ring-emerald-100" />
            <span className="mt-1 block text-xs text-slate-500">Letters, numbers and hyphens only. This is used when signing in.</span>
          </label>
          {error && <p role="alert" className="rounded-lg bg-rose-50 px-3 py-2 text-sm text-rose-700">{error}</p>}
          <button disabled={submitting} className="w-full rounded-lg bg-emerald-600 px-4 py-3 text-sm font-semibold text-white hover:bg-emerald-700 disabled:cursor-not-allowed disabled:opacity-60">
            {submitting ? 'Creating workspace…' : 'Create workspace'}
          </button>
        </form>
        <p className="mt-6 text-sm text-slate-600">Already have an account? <Link className="font-semibold text-emerald-700 hover:underline" href="/login">Sign in</Link></p>
      </section>
    </main>
  );
}
