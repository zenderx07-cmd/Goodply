'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { ApiError, apiRequest } from '@/lib/api-client';

type AuthResponse = {
  user: { id: string; email: string; full_name: string };
  organization: { id: string; name: string; slug: string; status: string; tier: string };
  roles: string[];
  permissions: string[];
};
type Branch = { id: string; name: string; code: string; city: string | null; timezone: string; is_active: boolean };

export default function WorkspacePage() {
  const router = useRouter();
  const [identity, setIdentity] = useState<AuthResponse | null>(null);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    async function load() {
      try {
        const current = await apiRequest<AuthResponse>('/auth/me');
        const locations = await apiRequest<Branch[]>('/branches');
        if (active) {
          setIdentity(current);
          setBranches(locations);
        }
      } catch (cause) {
        if (cause instanceof ApiError && cause.status === 401) router.replace('/login');
        else if (active) setError(cause instanceof Error ? cause.message : 'Unable to load workspace.');
      } finally {
        if (active) setLoading(false);
      }
    }
    void load();
    return () => { active = false; };
  }, [router]);

  async function signOut() {
    setError('');
    try {
      await apiRequest<void>('/auth/logout', { method: 'POST' });
      router.replace('/login');
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : 'Unable to sign out. Please retry.');
    }
  }

  if (loading) return <main className="min-h-screen bg-slate-50 p-8 text-slate-600">Loading your workspace…</main>;
  if (!identity) return <main className="min-h-screen bg-slate-50 p-8 text-slate-600">{error || 'Redirecting to sign in…'}</main>;

  return (
    <main className="min-h-screen bg-slate-50 px-5 py-10 text-slate-900">
      <div className="mx-auto max-w-5xl">
        <header className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-5">
          <Link href="/" className="text-2xl font-bold tracking-tight">goodply<span className="text-emerald-600">.</span></Link>
          <button onClick={signOut} className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-medium hover:bg-white">Sign out</button>
        </header>
        <section className="py-10">
          <p className="text-sm font-semibold uppercase tracking-widest text-emerald-700">Your workspace</p>
          <h1 className="mt-2 text-3xl font-semibold">Welcome, {identity.user.full_name}</h1>
          <p className="mt-2 text-slate-600">{identity.organization.name} <span className="text-slate-400">·</span> {identity.organization.slug}</p>
          <div className="mt-6 flex flex-wrap gap-2">
            {identity.roles.map((role) => <span key={role} className="rounded-full bg-emerald-50 px-3 py-1 text-sm font-medium capitalize text-emerald-800">{role.replaceAll('_', ' ')}</span>)}
          </div>
        </section>
        <section className="grid gap-5 md:grid-cols-2">
          <div className="rounded-2xl border border-slate-200 bg-white p-6">
            <h2 className="text-lg font-semibold">Branches you can access</h2>
            <p className="mt-1 text-sm text-slate-500">Branch visibility follows your organization role and assigned scope.</p>
            <div className="mt-5 space-y-3">
              {branches.length ? branches.map((branch) => (
                <div key={branch.id} className="flex items-start justify-between border-b border-slate-100 pb-3 last:border-0">
                  <div><p className="font-medium">{branch.name}</p><p className="text-sm text-slate-500">{branch.code}{branch.city ? ` · ${branch.city}` : ''}</p></div>
                  <span className="text-xs text-slate-400">{branch.timezone}</span>
                </div>
              )) : <p className="text-sm text-slate-500">No branches are assigned to this account yet.</p>}
            </div>
          </div>
          <div className="rounded-2xl border border-slate-200 bg-white p-6">
            <h2 className="text-lg font-semibold">Access permissions</h2>
            <p className="mt-1 text-sm text-slate-500">Your active permissions are loaded from the database.</p>
            <div className="mt-5 flex flex-wrap gap-2">
              {identity.permissions.map((permission) => <span key={permission} className="rounded-md bg-slate-100 px-2.5 py-1 text-xs text-slate-700">{permission}</span>)}
            </div>
          </div>
        </section>
        {error && <p role="alert" className="mt-5 rounded-lg bg-rose-50 px-4 py-3 text-sm text-rose-700">{error}</p>}
        <p className="mt-8 text-sm text-slate-500">This is the Stage 2 identity workspace. Business modules will be connected in later stages.</p>
      </div>
    </main>
  );
}
