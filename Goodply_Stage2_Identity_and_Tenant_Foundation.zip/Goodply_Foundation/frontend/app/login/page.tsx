'use client';

import Link from 'next/link';
import { type FormEvent, useState } from 'react';
import { useRouter } from 'next/navigation';
import { ApiError, apiRequest } from '@/lib/api-client';

type AuthResponse = {
  user: { id: string; email: string; full_name: string };
  organization: { id: string; name: string; slug: string; status: string; tier: string };
  roles: string[];
  permissions: string[];
};

export default function LoginPage() {
  const router = useRouter();
  const [organizationSlug, setOrganizationSlug] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      await apiRequest<AuthResponse>('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ organization_slug: organizationSlug, email, password }),
      });
      router.replace('/workspace');
    } catch (cause) {
      setError(cause instanceof ApiError ? cause.message : 'Unable to sign in. Please try again.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-50 px-5 py-12 text-slate-900">
      <section className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-8 shadow-sm">
        <Link href="/" className="text-2xl font-bold tracking-tight">goodply<span className="text-emerald-600">.</span></Link>
        <h1 className="mt-8 text-2xl font-semibold">Sign in to your workspace</h1>
        <p className="mt-2 text-sm text-slate-600">Use the organization address provided by your administrator.</p>
        <form onSubmit={handleSubmit} className="mt-7 space-y-4">
          <label className="block text-sm font-medium">Organization address
            <input required minLength={3} maxLength={63} autoCapitalize="none" value={organizationSlug} onChange={(event) => setOrganizationSlug(event.target.value.toLowerCase())} className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2.5 outline-none focus:border-emerald-600 focus:ring-2 focus:ring-emerald-100" placeholder="your-company" />
          </label>
          <label className="block text-sm font-medium">Email
            <input required type="email" autoComplete="username" value={email} onChange={(event) => setEmail(event.target.value)} className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2.5 outline-none focus:border-emerald-600 focus:ring-2 focus:ring-emerald-100" placeholder="you@company.com" />
          </label>
          <label className="block text-sm font-medium">Password
            <input required type="password" autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} className="mt-1.5 w-full rounded-lg border border-slate-300 px-3 py-2.5 outline-none focus:border-emerald-600 focus:ring-2 focus:ring-emerald-100" />
          </label>
          {error && <p role="alert" className="rounded-lg bg-rose-50 px-3 py-2 text-sm text-rose-700">{error}</p>}
          <button disabled={submitting} className="w-full rounded-lg bg-emerald-600 px-4 py-3 text-sm font-semibold text-white hover:bg-emerald-700 disabled:cursor-not-allowed disabled:opacity-60">
            {submitting ? 'Signing in…' : 'Sign in'}
          </button>
        </form>
        <p className="mt-6 text-sm text-slate-600">New to Goodply? <Link className="font-semibold text-emerald-700 hover:underline" href="/register">Create an organization</Link></p>
      </section>
    </main>
  );
}
