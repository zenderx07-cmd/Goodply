'use client';

import { useEffect, useState } from 'react';
import { ApiError, apiRequest } from '@/lib/api-client';

type HealthResponse = {
  status: string;
  checks: Record<string, { status: string; latency_ms?: number }>;
};

export default function StatusPage() {
  const [result, setResult] = useState<HealthResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    apiRequest<HealthResponse>('/health/ready')
      .then((data) => { if (active) setResult(data); })
      .catch((reason: unknown) => {
        if (!active) return;
        setError(reason instanceof ApiError ? reason.message : 'Unable to retrieve system status.');
      })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);

  return (
    <main className="min-h-screen bg-slate-50 px-6 py-12 text-slate-900">
      <div className="mx-auto max-w-3xl">
        <a href="/" className="text-sm font-semibold text-emerald-700">← Goodply</a>
        <h1 className="mt-8 text-3xl font-semibold">System status</h1>
        <p className="mt-2 text-slate-600">Live dependency readiness reported by the Goodply API.</p>
        <section className="mt-8 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
          {loading && <p role="status">Checking services…</p>}
          {!loading && error && <p role="alert" className="text-rose-700">{error}</p>}
          {!loading && result && (
            <>
              <p className="font-semibold">Overall: {result.status.replace('_', ' ')}</p>
              <dl className="mt-5 divide-y divide-slate-100">
                {Object.entries(result.checks).map(([name, check]) => (
                  <div key={name} className="flex items-center justify-between py-3">
                    <dt className="capitalize">{name}</dt>
                    <dd className="text-sm text-slate-600">
                      {check.status}{check.latency_ms !== undefined ? ` · ${check.latency_ms} ms` : ''}
                    </dd>
                  </div>
                ))}
              </dl>
            </>
          )}
        </section>
      </div>
    </main>
  );
}
