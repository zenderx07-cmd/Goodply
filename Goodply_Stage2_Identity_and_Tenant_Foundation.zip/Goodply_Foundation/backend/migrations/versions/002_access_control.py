"""002_access_control

Revision ID: 002_access_control
Revises: 001_core_identity
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "002_access_control"
down_revision = "001_core_identity"
branch_labels = None
depends_on = None

PERMISSIONS = [
    ("organization:read", "organization", "View organization profile"),
    ("organization:update", "organization", "Update organization profile"),
    ("organization:delete", "organization", "Delete organization"),
    ("branches:read", "branches", "View branches"),
    ("branches:manage", "branches", "Create and manage branches"),
    ("members:read", "members", "View organization members"),
    ("members:invite", "members", "Invite organization members"),
    ("members:manage", "members", "Manage organization members"),
    ("roles:read", "access_control", "View roles and permissions"),
    ("roles:manage", "access_control", "Manage roles and permissions"),
    ("departments:read", "workforce", "View departments"),
    ("departments:manage", "workforce", "Manage departments"),
    ("audit:read", "security", "View audit events"),
    ("analytics:read", "analytics", "View analytics and reports"),
    ("analytics:manage", "analytics", "Manage dashboards and reports"),
    ("reviews:read", "reputation", "View reviews"),
    ("reviews:respond", "reputation", "Respond to reviews"),
    ("crm:read", "crm", "View CRM records"),
    ("crm:write", "crm", "Create and update CRM records"),
    ("inbox:read", "inbox", "View conversations"),
    ("inbox:reply", "inbox", "Reply to conversations"),
    ("tickets:read", "helpdesk", "View support tickets"),
    ("tickets:manage", "helpdesk", "Manage support tickets"),
    ("tasks:read", "operations", "View tasks"),
    ("tasks:manage", "operations", "Manage tasks"),
    ("sales:read", "sales", "View sales pipeline"),
    ("sales:manage", "sales", "Manage sales pipeline"),
    ("marketing:read", "marketing", "View marketing campaigns"),
    ("marketing:manage", "marketing", "Manage marketing campaigns"),
    ("inventory:read", "inventory", "View inventory"),
    ("inventory:write", "inventory", "Manage inventory"),
    ("workforce:read", "workforce", "View workforce records"),
    ("workforce:manage", "workforce", "Manage workforce records"),
    ("integrations:read", "integrations", "View integrations"),
    ("integrations:manage", "integrations", "Manage integrations"),
    ("settings:manage", "settings", "Manage organization settings"),
]


def _tenant_policy(table: str) -> None:
    op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
    op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
    op.execute(
        f"""CREATE POLICY {table}_tenant_access ON {table}
        AS PERMISSIVE FOR ALL
        USING (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid)
        WITH CHECK (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid)"""
    )


def upgrade() -> None:
    op.create_table(
        "permissions",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("key", sa.String(100), nullable=False, unique=True),
        sa.Column("module", sa.String(50), nullable=False),
        sa.Column("description", sa.String(255), nullable=False),
    )
    permission_table = sa.table("permissions", sa.column("key", sa.String), sa.column("module", sa.String), sa.column("description", sa.String))
    op.bulk_insert(permission_table, [{"key": key, "module": module, "description": description} for key, module, description in PERMISSIONS])
    op.create_table(
        "roles",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("organization_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False),
        sa.Column("name", sa.String(100), nullable=False),
        sa.Column("slug", sa.String(80), nullable=False),
        sa.Column("description", sa.String(255), nullable=True),
        sa.Column("is_system", sa.Boolean(), server_default=sa.text("false"), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("NOW()"), nullable=False),
        sa.UniqueConstraint("organization_id", "slug", name="uq_roles_org_slug"),
        sa.UniqueConstraint("organization_id", "id", name="uq_roles_org_id"),
    )
    op.create_table(
        "role_permissions",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("organization_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("role_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("permission_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("permissions.id", ondelete="CASCADE"), nullable=False),
        sa.ForeignKeyConstraint(["organization_id", "role_id"], ["roles.organization_id", "roles.id"], ondelete="CASCADE"),
        sa.UniqueConstraint("organization_id", "role_id", "permission_id", name="uq_role_permission"),
    )
    op.create_table(
        "membership_roles",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("organization_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("membership_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("role_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.ForeignKeyConstraint(["organization_id", "membership_id"], ["organization_memberships.organization_id", "organization_memberships.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["organization_id", "role_id"], ["roles.organization_id", "roles.id"], ondelete="CASCADE"),
        sa.UniqueConstraint("organization_id", "membership_id", "role_id", name="uq_membership_role"),
    )
    for table in ("roles", "role_permissions", "membership_roles"):
        _tenant_policy(table)


def downgrade() -> None:
    for table in ("membership_roles", "role_permissions", "roles"):
        op.execute(f"DROP POLICY IF EXISTS {table}_tenant_access ON {table}")
        op.drop_table(table)
    op.drop_table("permissions")
