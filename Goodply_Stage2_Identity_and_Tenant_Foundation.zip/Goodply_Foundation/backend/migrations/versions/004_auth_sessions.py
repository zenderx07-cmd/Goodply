"""004_auth_sessions

Revision ID: 004_auth_sessions
Revises: 003_organization_lifecycle

The refresh-token table incorporates the rotation/reuse-detection fields proposed
in supplied migration 012, rather than creating a second incompatible table later.
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "004_auth_sessions"
down_revision = "003_organization_lifecycle"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "auth_refresh_tokens",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("organization_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("token_hash", sa.String(64), nullable=False, unique=True),
        sa.Column("family_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("is_revoked", sa.Boolean(), server_default=sa.text("false"), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("NOW()"), nullable=False),
        sa.Column("used_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("replaced_by_token_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("revoked_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("revocation_reason", sa.String(80), nullable=True),
        sa.ForeignKeyConstraint(["organization_id", "user_id"], ["organization_memberships.organization_id", "organization_memberships.user_id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["organization_id", "replaced_by_token_id"], ["auth_refresh_tokens.organization_id", "auth_refresh_tokens.id"]),
        sa.UniqueConstraint("organization_id", "id", name="uq_refresh_tokens_org_id"),
    )
    op.create_index("ix_refresh_tokens_family", "auth_refresh_tokens", ["organization_id", "family_id"])
    op.create_index("ix_refresh_tokens_user_expiry", "auth_refresh_tokens", ["organization_id", "user_id", "expires_at"])
    op.execute("ALTER TABLE auth_refresh_tokens ENABLE ROW LEVEL SECURITY")
    op.execute("ALTER TABLE auth_refresh_tokens FORCE ROW LEVEL SECURITY")
    op.execute("""CREATE POLICY auth_refresh_tokens_tenant_access ON auth_refresh_tokens
        AS PERMISSIVE FOR ALL
        USING (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid)
        WITH CHECK (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid)""")


def downgrade() -> None:
    op.execute("DROP POLICY IF EXISTS auth_refresh_tokens_tenant_access ON auth_refresh_tokens")
    op.drop_table("auth_refresh_tokens")
