"""001_core_identity

Revision ID: 001_core_identity
Revises: None
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "001_core_identity"
down_revision = None
branch_labels = None
depends_on = None


def _tenant_policy(table: str) -> None:
    op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
    op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY")
    op.execute(
        f"""CREATE POLICY {table}_tenant_access ON {table}
        AS PERMISSIVE FOR ALL
        USING (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid)
        WITH CHECK (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid)"""
    )


def upgrade() -> None:
    op.execute("REVOKE CREATE ON SCHEMA public FROM PUBLIC")
    op.create_table(
        "organizations",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("name", sa.String(200), nullable=False),
        sa.Column("slug", sa.String(63), nullable=False),
        sa.Column("status", sa.String(20), server_default="active", nullable=False),
        sa.Column("tier", sa.String(30), server_default="starter", nullable=False),
        sa.Column("ai_token_allowance_monthly", sa.Integer(), server_default="100000", nullable=False),
        sa.Column("ai_tokens_consumed_current_cycle", sa.Integer(), server_default="0", nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("NOW()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("NOW()"), nullable=False),
        sa.UniqueConstraint("slug", name="uq_organizations_slug"),
        sa.CheckConstraint("status IN ('active','trial','suspended','closed')", name="ck_organizations_status"),
        sa.CheckConstraint("tier IN ('starter','professional','business','enterprise')", name="ck_organizations_tier"),
        sa.CheckConstraint("ai_token_allowance_monthly >= 0 AND ai_tokens_consumed_current_cycle >= 0", name="ck_organizations_ai_usage_nonnegative"),
    )
    op.create_table(
        "organization_directory",
        sa.Column("organization_id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("slug", sa.String(63), nullable=False, unique=True),
        sa.Column("display_name", sa.String(200), nullable=False),
        sa.Column("status", sa.String(20), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("NOW()"), nullable=False),
    )
    # Only non-sensitive organization locator data is exposed for the login selector.
    op.execute("""
        CREATE OR REPLACE FUNCTION sync_organization_directory()
        RETURNS TRIGGER
        LANGUAGE plpgsql
        SECURITY DEFINER
        SET search_path = pg_catalog, public, pg_temp
        AS $$
        BEGIN
            IF TG_OP = 'DELETE' THEN
                DELETE FROM public.organization_directory WHERE organization_id = OLD.id;
                RETURN OLD;
            END IF;
            INSERT INTO public.organization_directory (organization_id, slug, display_name, status)
            VALUES (NEW.id, NEW.slug, NEW.name, NEW.status)
            ON CONFLICT (organization_id) DO UPDATE SET
                slug = EXCLUDED.slug,
                display_name = EXCLUDED.display_name,
                status = EXCLUDED.status;
            RETURN NEW;
        END;
        $$;
    """)
    op.execute("""CREATE TRIGGER trg_sync_organization_directory
        AFTER INSERT OR UPDATE OR DELETE ON organizations
        FOR EACH ROW EXECUTE FUNCTION sync_organization_directory()""")
    op.execute("ALTER TABLE organizations ENABLE ROW LEVEL SECURITY")
    op.execute("ALTER TABLE organizations FORCE ROW LEVEL SECURITY")
    op.execute("""CREATE POLICY organizations_tenant_access ON organizations
        AS PERMISSIVE FOR ALL
        USING (id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid)
        WITH CHECK (id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid)""")
    op.create_table(
        "users",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("email", sa.String(320), nullable=False),
        sa.Column("email_normalized", sa.String(320), nullable=False),
        sa.Column("password_hash", sa.String(512), nullable=False),
        sa.Column("full_name", sa.String(120), nullable=False),
        sa.Column("is_active", sa.Boolean(), server_default=sa.text("true"), nullable=False),
        sa.Column("email_verified_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_login_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("NOW()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("NOW()"), nullable=False),
        sa.UniqueConstraint("email_normalized", name="uq_users_email_normalized"),
        sa.CheckConstraint("email_normalized = lower(trim(email_normalized))", name="ck_users_email_normalized"),
    )
    op.create_table(
        "user_identity_directory",
        sa.Column("user_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), primary_key=True),
        sa.Column("email_normalized", sa.String(320), nullable=False, unique=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("NOW()"), nullable=False),
    )
    # The identity locator is internal to authentication flows and stores no password hash.
    op.execute("""
        CREATE OR REPLACE FUNCTION sync_user_identity_directory()
        RETURNS TRIGGER
        LANGUAGE plpgsql
        SECURITY DEFINER
        SET search_path = pg_catalog, public, pg_temp
        AS $$
        BEGIN
            IF TG_OP = 'DELETE' THEN
                DELETE FROM public.user_identity_directory WHERE user_id = OLD.id;
                RETURN OLD;
            END IF;
            INSERT INTO public.user_identity_directory (user_id, email_normalized)
            VALUES (NEW.id, NEW.email_normalized)
            ON CONFLICT (user_id) DO UPDATE SET
                email_normalized = EXCLUDED.email_normalized;
            RETURN NEW;
        END;
        $$;
    """)
    op.execute("""CREATE TRIGGER trg_sync_user_identity_directory
        AFTER INSERT OR UPDATE OF email_normalized OR DELETE ON users
        FOR EACH ROW EXECUTE FUNCTION sync_user_identity_directory()""")
    # Return only an account ID for an exact email match; do not grant table-wide directory reads.
    op.execute("""
        CREATE OR REPLACE FUNCTION lookup_user_id_by_email(p_email TEXT)
        RETURNS UUID
        LANGUAGE SQL
        STABLE
        SECURITY DEFINER
        SET search_path = pg_catalog, public
        AS $$
            SELECT user_id
            FROM public.user_identity_directory
            WHERE email_normalized = lower(btrim(p_email))
            LIMIT 1
        $$
    """)
    op.execute("REVOKE ALL ON FUNCTION lookup_user_id_by_email(TEXT) FROM PUBLIC")
    op.create_table(
        "branches",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("organization_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False),
        sa.Column("name", sa.String(150), nullable=False),
        sa.Column("code", sa.String(30), nullable=False),
        sa.Column("address", sa.String(500), nullable=True),
        sa.Column("city", sa.String(120), nullable=True),
        sa.Column("country_code", sa.String(2), nullable=True),
        sa.Column("timezone", sa.String(64), server_default="UTC", nullable=False),
        sa.Column("phone", sa.String(40), nullable=True),
        sa.Column("is_active", sa.Boolean(), server_default=sa.text("true"), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("NOW()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("NOW()"), nullable=False),
        sa.UniqueConstraint("organization_id", "code", name="uq_branches_org_code"),
        sa.UniqueConstraint("organization_id", "id", name="uq_branches_org_id"),
    )
    op.create_index("ix_branches_org_active", "branches", ["organization_id", "is_active"])
    op.create_table(
        "organization_memberships",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("organization_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("status", sa.String(20), server_default="active", nullable=False),
        sa.Column("scope_level", sa.String(20), server_default="branches", nullable=False),
        sa.Column("job_title", sa.String(120), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("NOW()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("NOW()"), nullable=False),
        sa.UniqueConstraint("organization_id", "user_id", name="uq_membership_org_user"),
        sa.UniqueConstraint("organization_id", "id", name="uq_membership_org_id"),
        sa.CheckConstraint("status IN ('active','invited','suspended','left')", name="ck_membership_status"),
        sa.CheckConstraint("scope_level IN ('organization','branches','department')", name="ck_membership_scope_level"),
    )
    op.create_index("ix_memberships_user_status", "organization_memberships", ["user_id", "status"])
    _tenant_policy("branches")
    _tenant_policy("organization_memberships")
    # User rows are visible only to the signed-in user or to members of the active tenant.
    # The identity directory above is used only to locate an account during invite acceptance.
    op.execute("ALTER TABLE users ENABLE ROW LEVEL SECURITY")
    op.execute("ALTER TABLE users FORCE ROW LEVEL SECURITY")
    op.execute("""CREATE POLICY users_tenant_or_self_access ON users
        AS PERMISSIVE FOR ALL
        USING (
            id = NULLIF(current_setting('app.current_user_id', true), '')::uuid
            OR EXISTS (
                SELECT 1 FROM organization_memberships m
                WHERE m.user_id = users.id
                  AND m.organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid
            )
        )
        WITH CHECK (
            id = NULLIF(current_setting('app.current_user_id', true), '')::uuid
            OR EXISTS (
                SELECT 1 FROM organization_memberships m
                WHERE m.user_id = users.id
                  AND m.organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid
            )
        )""")


def downgrade() -> None:
    op.execute("DROP TRIGGER IF EXISTS trg_sync_organization_directory ON organizations")
    op.execute("DROP FUNCTION IF EXISTS sync_organization_directory()")
    op.execute("DROP TRIGGER IF EXISTS trg_sync_user_identity_directory ON users")
    op.execute("DROP FUNCTION IF EXISTS sync_user_identity_directory()")
    op.execute("DROP FUNCTION IF EXISTS lookup_user_id_by_email(TEXT)")
    op.execute("DROP POLICY IF EXISTS users_tenant_or_self_access ON users")
    op.execute("DROP POLICY IF EXISTS organizations_tenant_access ON organizations")
    for table in ("organization_memberships", "branches"):
        op.execute(f"DROP POLICY IF EXISTS {table}_tenant_access ON {table}")
    op.drop_table("organization_memberships")
    op.drop_index("ix_branches_org_active", table_name="branches")
    op.drop_table("branches")
    op.drop_table("user_identity_directory")
    op.drop_table("users")
    op.drop_table("organization_directory")
    op.drop_table("organizations")
