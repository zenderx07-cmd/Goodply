from uuid import uuid4

import jwt
import pytest

from app.core.security import (
    create_access_token,
    decode_access_token,
    extract_refresh_organization,
    hash_opaque_token,
    hash_password,
    normalize_email,
    verify_password,
)


def test_password_hash_is_argon2_and_round_trips() -> None:
    password = "Correct Horse Battery Staple 2026!"
    hashed = hash_password(password)
    assert hashed.startswith("$argon2id$")
    assert verify_password(password, hashed)
    assert not verify_password("not-the-password", hashed)


def test_password_minimum_length_is_enforced() -> None:
    with pytest.raises(ValueError, match="12 characters"):
        hash_password("short")


def test_access_token_contains_bound_user_organization_and_session() -> None:
    user_id, organization_id, family_id = uuid4(), uuid4(), uuid4()
    token = create_access_token(user_id, organization_id, family_id)
    claims = decode_access_token(token)
    assert claims["sub"] == str(user_id)
    assert claims["org"] == str(organization_id)
    assert claims["sid"] == str(family_id)
    assert claims["typ"] == "access"


def test_access_token_rejects_wrong_signature() -> None:
    token = create_access_token(uuid4(), uuid4(), uuid4())
    parts = token.split(".")
    parts[-1] = "invalid-signature"
    with pytest.raises(jwt.PyJWTError):
        decode_access_token(".".join(parts))


def test_refresh_token_embeds_tenant_prefix_and_hash_is_one_way() -> None:
    organization_id = uuid4()
    raw = f"{organization_id}." + "a" * 64
    assert extract_refresh_organization(raw) == organization_id
    assert hash_opaque_token(raw) != raw
    with pytest.raises(ValueError, match="Malformed"):
        extract_refresh_organization("not-a-token")


def test_email_normalization_is_case_and_whitespace_insensitive() -> None:
    assert normalize_email("  Good.Ply@Example.COM ") == "good.ply@example.com"


def test_access_token_rejects_wrong_token_type() -> None:
    from datetime import datetime, timedelta, timezone

    from app.core.config import settings

    now = datetime.now(timezone.utc)
    wrong_type = jwt.encode(
        {
            "sub": str(uuid4()),
            "org": str(uuid4()),
            "sid": str(uuid4()),
            "iat": now,
            "nbf": now,
            "exp": now + timedelta(minutes=5),
            "iss": "goodply-api",
            "aud": "goodply-app",
            "typ": "refresh",
        },
        settings.auth_signing_key,
        algorithm="HS256",
    )
    with pytest.raises(jwt.PyJWTError, match="Unexpected token type"):
        decode_access_token(wrong_type)


def test_runtime_database_role_must_be_restricted() -> None:
    from app.core.database import validate_runtime_role

    validate_runtime_role("goodply_app", False, False, "goodply_app")
    with pytest.raises(RuntimeError, match="expected the restricted role"):
        validate_runtime_role("goodply", True, True, "goodply_app")
    with pytest.raises(RuntimeError, match="NOSUPERUSER and NOBYPASSRLS"):
        validate_runtime_role("goodply_app", False, True, "goodply_app")
    with pytest.raises(RuntimeError, match="NOSUPERUSER and NOBYPASSRLS"):
        validate_runtime_role("goodply_app", True, False, "goodply_app")
