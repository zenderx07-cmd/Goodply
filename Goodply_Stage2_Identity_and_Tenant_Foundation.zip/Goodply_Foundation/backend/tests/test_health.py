from fastapi.testclient import TestClient

from app.main import app
from app.modules.system import health


def test_liveness_is_independent_of_external_services() -> None:
    with TestClient(app) as client:
        response = client.get("/api/v1/health/live")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_readiness_returns_503_when_a_dependency_is_unavailable(monkeypatch) -> None:
    async def database_ok():
        return {"status": "ok", "latency_ms": 1.0}

    async def redis_down():
        return {"status": "unavailable"}

    monkeypatch.setattr(health, "check_database", database_ok)
    monkeypatch.setattr(health, "check_redis", redis_down)
    with TestClient(app) as client:
        response = client.get("/api/v1/health/ready")
    assert response.status_code == 503
    assert response.json()["status"] == "not_ready"


def test_readiness_returns_200_when_all_dependencies_are_healthy(monkeypatch) -> None:
    async def dependency_ok():
        return {"status": "ok", "latency_ms": 1.0}

    monkeypatch.setattr(health, "check_database", dependency_ok)
    monkeypatch.setattr(health, "check_redis", dependency_ok)
    with TestClient(app) as client:
        response = client.get("/api/v1/health/ready")
    assert response.status_code == 200
    assert response.json()["status"] == "ready"


def test_production_configuration_rejects_missing_secrets() -> None:
    import pytest
    from app.core.config import Settings

    configuration = Settings(
        _env_file=None,
        ENVIRONMENT="production",
        DATABASE_URL=None,
        REDIS_URL=None,
        SECRET_KEY=None,
    )
    with pytest.raises(RuntimeError, match="DATABASE_URL"):
        configuration.validate_production_configuration()


def test_production_configuration_accepts_required_secret_material() -> None:
    from pydantic import SecretStr
    from app.core.config import Settings

    configuration = Settings(
        _env_file=None,
        ENVIRONMENT="production",
        DATABASE_URL="postgresql+asyncpg://user:password@db:5432/goodply",
        REDIS_URL="redis://redis:6379/0",
        SECRET_KEY=SecretStr("x" * 40),
    )
    configuration.validate_production_configuration()
