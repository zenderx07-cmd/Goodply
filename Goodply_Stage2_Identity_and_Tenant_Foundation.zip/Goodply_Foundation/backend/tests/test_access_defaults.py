from app.modules.identity.access_defaults import READ_ONLY_PREFIXES, ROLE_TEMPLATES


def test_default_role_catalog_covers_expected_business_roles() -> None:
    expected = {
        "owner",
        "administrator",
        "general_manager",
        "branch_manager",
        "department_manager",
        "supervisor",
        "customer_support_agent",
        "sales_representative",
        "employee",
        "auditor",
    }
    assert set(ROLE_TEMPLATES) == expected


def test_auditor_role_is_limited_to_read_permissions() -> None:
    assert READ_ONLY_PREFIXES
    assert all(key.endswith(":read") for key in READ_ONLY_PREFIXES)
    assert not any(key.endswith(":manage") or key.endswith(":write") for key in READ_ONLY_PREFIXES)


def test_owner_template_is_the_only_wildcard_role() -> None:
    wildcard_roles = {
        slug for slug, (_name, _description, permissions) in ROLE_TEMPLATES.items()
        if "*" in permissions
    }
    assert wildcard_roles == {"owner"}


def test_branch_scope_and_auditor_role_templates_are_defined() -> None:
    branch_manager_permissions = ROLE_TEMPLATES["branch_manager"][2]
    assert "inventory:write" in branch_manager_permissions
    assert "workforce:manage" in branch_manager_permissions
    assert "organization:delete" not in branch_manager_permissions
