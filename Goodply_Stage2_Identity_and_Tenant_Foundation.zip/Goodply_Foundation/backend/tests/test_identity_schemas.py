import pytest
from pydantic import ValidationError

from app.modules.identity.schemas import RegisterRequest


def test_registration_normalizes_and_validates_organization_slug() -> None:
    payload = RegisterRequest(
        full_name="Goodply Owner",
        email=" Owner@Example.com ",
        password="a long and secure password 2026",
        organization_name="Example Group",
        organization_slug="Example-Group",
    )
    assert payload.email == "Owner@Example.com"
    assert payload.organization_slug == "example-group"


def test_registration_rejects_invalid_slug_and_short_password() -> None:
    with pytest.raises(ValidationError):
        RegisterRequest(
            full_name="Owner",
            email="owner@example.com",
            password="short",
            organization_name="Example",
            organization_slug="Bad Slug!",
        )


def test_registration_rejects_blank_names_and_normalizes_login_slug() -> None:
    from app.modules.identity.schemas import LoginRequest

    with pytest.raises(ValidationError):
        RegisterRequest(
            full_name="  ",
            email="owner@example.com",
            password="a long and secure password 2026",
            organization_name="Example Group",
            organization_slug="example-group",
        )
    login = LoginRequest(
        organization_slug="  Example-Group ",
        email="Owner@Example.com",
        password="valid-password",
    )
    assert login.organization_slug == "example-group"
    assert login.email == "Owner@Example.com"


def test_invitation_rejects_duplicate_branch_scopes() -> None:
    from uuid import uuid4
    from app.modules.identity.schemas import InvitationCreateRequest

    branch_id = uuid4()
    with pytest.raises(ValidationError, match="duplicates"):
        InvitationCreateRequest(
            email="teammate@example.com",
            role_id=uuid4(),
            branch_ids=[branch_id, branch_id],
        )


def test_branch_validation_requires_valid_iana_timezone_and_country_code() -> None:
    from app.modules.organizations.schemas import BranchCreate

    valid = BranchCreate(name="Head Office", code="HQ", timezone="Asia/Dubai", country_code="ae")
    assert valid.country_code == "AE"
    with pytest.raises(ValidationError):
        BranchCreate(name="Head Office", code="HQ", timezone="../../etc/passwd")
    with pytest.raises(ValidationError):
        BranchCreate(name="Head Office", code="HQ", country_code="1!")


def test_role_slug_is_normalized_before_pattern_validation() -> None:
    from app.modules.organizations.schemas import RoleCreate

    role = RoleCreate(name="Sales Manager", slug="Sales-Manager", permission_keys=[])
    assert role.slug == "sales-manager"


def test_pending_invitation_unique_index_is_declared() -> None:
    from app.modules.identity.models import OrganizationInvitation

    index = next(
        idx for idx in OrganizationInvitation.__table__.indexes
        if idx.name == "uq_invitations_org_email_pending"
    )
    assert index.unique is True
    assert "status = 'pending'" in str(index.dialect_options["postgresql"]["where"])
