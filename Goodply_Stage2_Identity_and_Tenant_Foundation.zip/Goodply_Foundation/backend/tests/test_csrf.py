from fastapi.testclient import TestClient

from app.main import app


def test_cookie_authenticated_write_requires_double_submit_csrf() -> None:
    with TestClient(app) as client:
        client.cookies.set("access_token", "session-cookie")
        response = client.post("/api/v1/branches", json={})
    assert response.status_code == 403
    assert "CSRF" in response.json()["detail"]


def test_openapi_exposes_identity_and_organization_routes() -> None:
    schema = app.openapi()
    paths = schema["paths"]
    assert "/api/v1/auth/register" in paths
    assert "/api/v1/auth/login" in paths
    assert "/api/v1/auth/refresh" in paths
    assert "/api/v1/organizations/current" in paths
    assert "/api/v1/roles" in paths
