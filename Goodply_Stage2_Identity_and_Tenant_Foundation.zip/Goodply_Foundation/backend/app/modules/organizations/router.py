from __future__ import annotations

from datetime import datetime, timedelta, timezone
from uuid import UUID
import secrets

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import delete, func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db_session
from app.core.dependencies import UserContext, branch_filter, get_current_user_context, require_permission
from app.core.security import hash_opaque_token, normalize_email
from app.modules.identity.models import (
    AuditLog,
    Branch,
    InvitationBranchScope,
    MembershipBranchScope,
    MembershipRole,
    Organization,
    OrganizationInvitation,
    OrganizationMembership,
    Permission,
    Role,
    RolePermission,
    User,
)
from app.modules.organizations.schemas import (
    BranchCreate,
    BranchRead,
    InvitationRead,
    MemberRead,
    OrganizationCurrentRead,
    RoleCreate,
    RoleRead,
    MemberRoleUpdate,
)
from app.modules.identity.schemas import InvitationCreateRequest

router = APIRouter(tags=["Organizations & Access"])


@router.get("/organizations/current", response_model=OrganizationCurrentRead)
async def current_organization(context: UserContext = Depends(get_current_user_context)) -> OrganizationCurrentRead:
    org = context.organization
    return OrganizationCurrentRead(id=org.id, name=org.name, slug=org.slug, status=org.status, tier=org.tier)


@router.get("/branches", response_model=list[BranchRead])
async def list_branches(
    context: UserContext = Depends(require_permission("branches:read")),
    session: AsyncSession = Depends(get_db_session),
) -> list[BranchRead]:
    query = select(Branch).where(
        Branch.organization_id == context.organization.id,
        Branch.is_active.is_(True),
    ).order_by(Branch.name)
    query = branch_filter(query, context)
    rows = (await session.execute(query)).scalars().all()
    return [BranchRead.model_validate(row) for row in rows]


@router.post("/branches", response_model=BranchRead, status_code=status.HTTP_201_CREATED)
async def create_branch(
    payload: BranchCreate,
    context: UserContext = Depends(require_permission("branches:manage")),
    session: AsyncSession = Depends(get_db_session),
) -> BranchRead:
    if not context.organization_wide:
        raise HTTPException(status_code=403, detail="Only organization-scoped administrators can create branches.")
    branch = Branch(
        organization_id=context.organization.id,
        name=payload.name.strip(),
        code=payload.code.strip().upper(),
        address=payload.address,
        city=payload.city,
        country_code=payload.country_code.upper() if payload.country_code else None,
        timezone=payload.timezone,
        phone=payload.phone,
    )
    session.add(branch)
    session.add(AuditLog(
        organization_id=context.organization.id,
        actor_user_id=context.user.id,
        action="branch.created",
        entity_type="branch",
        metadata_json={"code": payload.code.strip().upper()},
    ))
    try:
        await session.commit()
    except IntegrityError:
        await session.rollback()
        raise HTTPException(status_code=409, detail="A branch with that code already exists.") from None
    return BranchRead.model_validate(branch)


@router.get("/members", response_model=list[MemberRead])
async def list_members(
    context: UserContext = Depends(require_permission("members:read")),
    session: AsyncSession = Depends(get_db_session),
) -> list[MemberRead]:
    query = (
        select(OrganizationMembership, User)
        .join(User, User.id == OrganizationMembership.user_id)
        .where(OrganizationMembership.organization_id == context.organization.id)
        .order_by(User.full_name)
        .limit(200)
    )
    if not context.organization_wide:
        scoped_membership_ids = select(MembershipBranchScope.membership_id).where(
            MembershipBranchScope.organization_id == context.organization.id,
            MembershipBranchScope.branch_id.in_(context.branch_ids),
        )
        query = query.where(OrganizationMembership.id.in_(scoped_membership_ids))
    result = await session.execute(query)
    members: list[MemberRead] = []
    for membership, user in result.all():
        roles_result = await session.execute(
            select(Role.slug)
            .join(MembershipRole, MembershipRole.role_id == Role.id)
            .where(MembershipRole.organization_id == context.organization.id, MembershipRole.membership_id == membership.id)
        )
        scopes_result = await session.execute(
            select(MembershipBranchScope.branch_id).where(
                MembershipBranchScope.organization_id == context.organization.id,
                MembershipBranchScope.membership_id == membership.id,
            )
        )
        members.append(MemberRead(
            membership_id=membership.id,
            user_id=user.id,
            email=user.email,
            full_name=user.full_name,
            status=membership.status,
            scope_level=membership.scope_level,
            roles=sorted(set(roles_result.scalars().all())),
            branch_ids=list(scopes_result.scalars().all()),
        ))
    return members


@router.post("/organizations/current/invitations", response_model=InvitationRead, status_code=status.HTTP_201_CREATED)
async def create_invitation(
    payload: InvitationCreateRequest,
    context: UserContext = Depends(require_permission("members:invite")),
    session: AsyncSession = Depends(get_db_session),
) -> InvitationRead:
    data = payload

    role = await session.scalar(select(Role).where(
        Role.organization_id == context.organization.id,
        Role.id == data.role_id,
    ).with_for_update())
    if role is None:
        raise HTTPException(status_code=404, detail="Role not found in this organization.")
    target_permissions_result = await session.execute(
        select(Permission.key)
        .join(RolePermission, RolePermission.permission_id == Permission.id)
        .where(RolePermission.organization_id == context.organization.id, RolePermission.role_id == role.id)
    )
    target_permissions = set(target_permissions_result.scalars().all())
    if not target_permissions.issubset(context.permissions):
        raise HTTPException(status_code=403, detail="You cannot assign a role with permissions you do not hold.")
    if data.scope_level == "organization" and not context.organization_wide:
        raise HTTPException(status_code=403, detail="Only organization-scoped administrators can grant organization-wide access.")
    if data.scope_level == "organization" and data.branch_ids:
        raise HTTPException(status_code=422, detail="Do not supply branch_ids for organization-wide access.")
    if data.scope_level == "branches":
        if not data.branch_ids:
            raise HTTPException(status_code=422, detail="Select at least one branch for branch-scoped access.")
        valid_branches_result = await session.execute(
            select(Branch.id).where(
                Branch.organization_id == context.organization.id,
                Branch.id.in_(data.branch_ids),
                Branch.is_active.is_(True),
            )
        )
        valid_branch_ids = set(valid_branches_result.scalars().all())
        if valid_branch_ids != set(data.branch_ids):
            raise HTTPException(status_code=422, detail="One or more selected branches are unavailable.")
        if not context.organization_wide and not set(data.branch_ids).issubset(context.branch_ids):
            raise HTTPException(status_code=403, detail="You cannot invite users to branches outside your own scope.")

    normalized_email = normalize_email(data.email)
    pending = await session.execute(
        select(OrganizationInvitation).where(
            OrganizationInvitation.organization_id == context.organization.id,
            OrganizationInvitation.email_normalized == normalized_email,
            OrganizationInvitation.status == "pending",
        )
    )
    for old_invitation in pending.scalars().all():
        old_invitation.status = "revoked"
    raw_token = f"{context.organization.id}.{secrets.token_urlsafe(48)}"
    expires_at = datetime.now(timezone.utc) + timedelta(days=7)
    invitation = OrganizationInvitation(
        organization_id=context.organization.id,
        email_normalized=normalized_email,
        token_hash=hash_opaque_token(raw_token),
        role_id=role.id,
        invited_by_user_id=context.user.id,
        status="pending",
        scope_level=data.scope_level,
        expires_at=expires_at,
    )
    session.add(invitation)
    try:
        await session.flush()
    except IntegrityError:
        await session.rollback()
        raise HTTPException(
            status_code=409,
            detail="A pending invitation for this email already exists in this organization."
        ) from None
    for branch_id in data.branch_ids:
        session.add(InvitationBranchScope(
            organization_id=context.organization.id,
            invitation_id=invitation.id,
            branch_id=branch_id,
        ))
    session.add(AuditLog(
        organization_id=context.organization.id,
        actor_user_id=context.user.id,
        action="organization.invitation_created",
        entity_type="organization_invitation",
        entity_id=str(invitation.id),
        metadata_json={"email": normalized_email, "role": role.slug, "scope_level": data.scope_level},
    ))
    await session.commit()
    return InvitationRead(
        invitation_id=invitation.id,
        email=normalized_email,
        expires_at=expires_at,
        invitation_token=raw_token,
        note="Share this one-time token securely. Email delivery is not configured yet.",
    )


@router.get("/roles", response_model=list[RoleRead])
async def list_roles(
    context: UserContext = Depends(require_permission("roles:read")),
    session: AsyncSession = Depends(get_db_session),
) -> list[RoleRead]:
    roles = (await session.execute(
        select(Role).where(Role.organization_id == context.organization.id).order_by(Role.name)
    )).scalars().all()
    output: list[RoleRead] = []
    for role in roles:
        keys = await session.execute(
            select(Permission.key)
            .join(RolePermission, RolePermission.permission_id == Permission.id)
            .where(RolePermission.organization_id == context.organization.id, RolePermission.role_id == role.id)
            .order_by(Permission.key)
        )
        output.append(RoleRead(
            id=role.id, name=role.name, slug=role.slug, description=role.description,
            is_system=role.is_system, permission_keys=list(keys.scalars().all()),
        ))
    return output


@router.post("/roles", response_model=RoleRead, status_code=status.HTTP_201_CREATED)
async def create_role(
    payload: RoleCreate,
    context: UserContext = Depends(require_permission("roles:manage")),
    session: AsyncSession = Depends(get_db_session),
) -> RoleRead:
    requested = set(payload.permission_keys)
    permission_rows = await session.execute(select(Permission).where(Permission.key.in_(requested)))
    permissions = {row.key: row for row in permission_rows.scalars().all()}
    if set(permissions) != requested:
        raise HTTPException(status_code=422, detail="One or more permission keys are unknown.")
    if not requested.issubset(context.permissions):
        raise HTTPException(status_code=403, detail="You cannot grant permissions you do not hold.")
    role = Role(
        organization_id=context.organization.id,
        name=payload.name.strip(),
        slug=payload.slug,
        description=payload.description,
        is_system=False,
    )
    session.add(role)
    try:
        await session.flush()
    except IntegrityError:
        await session.rollback()
        raise HTTPException(status_code=409, detail="A role with that identifier already exists.") from None
    for permission in permissions.values():
        session.add(RolePermission(
            organization_id=context.organization.id,
            role_id=role.id,
            permission_id=permission.id,
        ))
    session.add(AuditLog(
        organization_id=context.organization.id,
        actor_user_id=context.user.id,
        action="access_control.role_created",
        entity_type="role",
        entity_id=str(role.id),
        metadata_json={"slug": role.slug, "permission_count": len(requested)},
    ))
    try:
        await session.commit()
    except IntegrityError:
        await session.rollback()
        raise HTTPException(status_code=409, detail="A role with that identifier already exists.") from None
    return RoleRead(
        id=role.id, name=role.name, slug=role.slug, description=role.description,
        is_system=role.is_system, permission_keys=sorted(requested),
    )


@router.put("/roles/{role_id}", response_model=RoleRead)
async def update_role(
    role_id: UUID,
    payload: RoleCreate,
    context: UserContext = Depends(require_permission("roles:manage")),
    session: AsyncSession = Depends(get_db_session),
) -> RoleRead:
    role = await session.scalar(select(Role).where(
        Role.organization_id == context.organization.id,
        Role.id == role_id,
    ).with_for_update())
    if role is None:
        raise HTTPException(status_code=404, detail="Role not found.")
    if role.slug == "owner":
        raise HTTPException(
            status_code=409,
            detail="The built-in owner role is protected to prevent organization lockout.",
        )
    requested = set(payload.permission_keys)
    permission_rows = await session.execute(select(Permission).where(Permission.key.in_(requested)))
    permissions = {row.key: row for row in permission_rows.scalars().all()}
    if set(permissions) != requested:
        raise HTTPException(status_code=422, detail="One or more permission keys are unknown.")
    if not requested.issubset(context.permissions):
        raise HTTPException(status_code=403, detail="You cannot grant permissions you do not hold.")
    role.name = payload.name.strip()
    role.slug = payload.slug
    role.description = payload.description
    await session.execute(
        delete(RolePermission).where(
            RolePermission.organization_id == context.organization.id,
            RolePermission.role_id == role.id,
        )
    )
    for permission in permissions.values():
        session.add(RolePermission(
            organization_id=context.organization.id,
            role_id=role.id,
            permission_id=permission.id,
        ))
    session.add(AuditLog(
        organization_id=context.organization.id,
        actor_user_id=context.user.id,
        action="access_control.role_updated",
        entity_type="role",
        entity_id=str(role.id),
        metadata_json={"slug": role.slug, "permission_count": len(requested)},
    ))
    try:
        await session.commit()
    except IntegrityError:
        await session.rollback()
        raise HTTPException(status_code=409, detail="A role with that identifier already exists.") from None
    return RoleRead(
        id=role.id, name=role.name, slug=role.slug, description=role.description,
        is_system=role.is_system, permission_keys=sorted(requested),
    )


@router.put("/members/{membership_id}/roles", status_code=status.HTTP_204_NO_CONTENT)
async def update_member_roles(
    membership_id: UUID,
    payload: MemberRoleUpdate,
    context: UserContext = Depends(require_permission("members:manage")),
    session: AsyncSession = Depends(get_db_session),
) -> None:
    # Serialize ownership changes for this tenant before counting active owners.
    await session.scalar(
        select(Organization.id)
        .where(Organization.id == context.organization.id)
        .with_for_update()
    )
    membership = await session.scalar(select(OrganizationMembership).where(
        OrganizationMembership.organization_id == context.organization.id,
        OrganizationMembership.id == membership_id,
    ).with_for_update())
    if membership is None:
        raise HTTPException(status_code=404, detail="Organization membership not found.")
    if not context.organization_wide:
        if membership.scope_level == "organization":
            raise HTTPException(status_code=403, detail="You cannot manage an organization-wide member.")
        target_scopes = await session.execute(select(MembershipBranchScope.branch_id).where(
            MembershipBranchScope.organization_id == context.organization.id,
            MembershipBranchScope.membership_id == membership.id,
        ))
        if not set(target_scopes.scalars().all()).issubset(context.branch_ids):
            raise HTTPException(status_code=403, detail="You cannot manage a member outside your branch scope.")
    roles_result = await session.execute(select(Role).where(
        Role.organization_id == context.organization.id,
        Role.id.in_(payload.role_ids),
    ).with_for_update())
    target_roles = list(roles_result.scalars().all())
    if len({role.id for role in target_roles}) != len(set(payload.role_ids)):
        raise HTTPException(status_code=422, detail="One or more roles are not available in this organization.")
    permissions_result = await session.execute(
        select(Permission.key)
        .join(RolePermission, RolePermission.permission_id == Permission.id)
        .where(
            RolePermission.organization_id == context.organization.id,
            RolePermission.role_id.in_(payload.role_ids),
        )
    )
    granted_permissions = set(permissions_result.scalars().all())
    if not granted_permissions.issubset(context.permissions):
        raise HTTPException(status_code=403, detail="You cannot assign roles with permissions you do not hold.")
    target_role_slugs = {role.slug for role in target_roles}
    if "owner" in target_role_slugs and "organization:delete" not in context.permissions:
        raise HTTPException(status_code=403, detail="Only an organization owner can assign the owner role.")

    current_role_slugs_result = await session.execute(
        select(Role.slug)
        .join(MembershipRole, MembershipRole.role_id == Role.id)
        .where(
            MembershipRole.organization_id == context.organization.id,
            MembershipRole.membership_id == membership.id,
        )
    )
    current_role_slugs = set(current_role_slugs_result.scalars().all())
    if "owner" in current_role_slugs and "owner" not in target_role_slugs:
        active_owner_count = await session.scalar(
            select(func.count(func.distinct(OrganizationMembership.id)))
            .join(MembershipRole, MembershipRole.membership_id == OrganizationMembership.id)
            .join(Role, Role.id == MembershipRole.role_id)
            .where(
                OrganizationMembership.organization_id == context.organization.id,
                OrganizationMembership.status == "active",
                MembershipRole.organization_id == context.organization.id,
                Role.organization_id == context.organization.id,
                Role.slug == "owner",
            )
        )
        if (active_owner_count or 0) <= 1:
            raise HTTPException(
                status_code=409,
                detail="The last active organization owner cannot be removed or downgraded.",
            )

    await session.execute(
        delete(MembershipRole).where(
            MembershipRole.organization_id == context.organization.id,
            MembershipRole.membership_id == membership.id,
        )
    )
    for role in target_roles:
        session.add(MembershipRole(
            organization_id=context.organization.id,
            membership_id=membership.id,
            role_id=role.id,
        ))
    session.add(AuditLog(
        organization_id=context.organization.id,
        actor_user_id=context.user.id,
        action="access_control.member_roles_updated",
        entity_type="organization_membership",
        entity_id=str(membership.id),
        metadata_json={"role_slugs": sorted(role.slug for role in target_roles)},
    ))
    await session.commit()
