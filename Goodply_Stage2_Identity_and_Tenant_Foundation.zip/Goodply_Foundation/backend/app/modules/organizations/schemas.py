from datetime import datetime
from uuid import UUID
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from pydantic import BaseModel, ConfigDict, Field, field_validator


class OrganizationCurrentRead(BaseModel):
    id: UUID
    name: str
    slug: str
    status: str
    tier: str


class BranchCreate(BaseModel):
    name: str = Field(min_length=2, max_length=150)
    code: str = Field(min_length=1, max_length=30, pattern=r"^[A-Za-z0-9_-]+$")
    address: str | None = Field(default=None, max_length=500)
    city: str | None = Field(default=None, max_length=120)
    country_code: str | None = Field(default=None, min_length=2, max_length=2, pattern=r"^[A-Za-z]{2}$")
    timezone: str = Field(default="UTC", min_length=1, max_length=64)
    phone: str | None = Field(default=None, max_length=40)

    @field_validator("name")
    @classmethod
    def valid_name(cls, value: str) -> str:
        value = value.strip()
        if len(value) < 2:
            raise ValueError("Branch name must contain at least 2 non-space characters")
        return value

    @field_validator("timezone")
    @classmethod
    def valid_timezone(cls, value: str) -> str:
        value = value.strip()
        try:
            ZoneInfo(value)
        except (ZoneInfoNotFoundError, ValueError):
            raise ValueError("Use a valid IANA time zone") from None
        return value

    @field_validator("country_code")
    @classmethod
    def normalize_country_code(cls, value: str | None) -> str | None:
        return value.upper() if value else None


class BranchRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    name: str
    code: str
    address: str | None
    city: str | None
    country_code: str | None
    timezone: str
    phone: str | None
    is_active: bool


class MemberRead(BaseModel):
    membership_id: UUID
    user_id: UUID
    email: str
    full_name: str
    status: str
    scope_level: str
    roles: list[str]
    branch_ids: list[UUID]


class InvitationRead(BaseModel):
    invitation_id: UUID
    email: str
    expires_at: datetime
    invitation_token: str
    note: str


class RoleCreate(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    slug: str = Field(min_length=2, max_length=80, pattern=r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
    description: str | None = Field(default=None, max_length=255)
    permission_keys: list[str] = Field(default_factory=list, max_length=100)

    @field_validator("name")
    @classmethod
    def valid_name(cls, value: str) -> str:
        value = value.strip()
        if len(value) < 2:
            raise ValueError("Role name must contain at least 2 non-space characters")
        return value

    @field_validator("slug", mode="before")
    @classmethod
    def normalize_slug(cls, value: str) -> str:
        return value.strip().lower() if isinstance(value, str) else value


class RoleRead(BaseModel):
    id: UUID
    name: str
    slug: str
    description: str | None
    is_system: bool
    permission_keys: list[str]


class MemberRoleUpdate(BaseModel):
    role_ids: list[UUID] = Field(min_length=1, max_length=20)

    @field_validator("role_ids")
    @classmethod
    def unique_role_ids(cls, values: list[UUID]) -> list[UUID]:
        if len(values) != len(set(values)):
            raise ValueError("Role IDs must not contain duplicates")
        return values
