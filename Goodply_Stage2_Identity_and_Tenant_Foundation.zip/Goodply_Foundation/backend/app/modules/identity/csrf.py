from __future__ import annotations

import secrets

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from app.core.config import settings


class DoubleSubmitCSRFMiddleware(BaseHTTPMiddleware):
    """Enforce a cookie/header double-submit token for cookie-authenticated writes."""

    EXEMPT_PATHS = {"/api/v1/auth/login", "/api/v1/auth/register", "/api/v1/auth/invitations/accept"}
    SAFE_METHODS = {"GET", "HEAD", "OPTIONS", "TRACE"}

    async def dispatch(self, request: Request, call_next) -> Response:
        if request.method.upper() not in self.SAFE_METHODS and request.url.path not in self.EXEMPT_PATHS:
            has_auth_cookie = bool(request.cookies.get("access_token") or request.cookies.get("refresh_token"))
            if has_auth_cookie:
                cookie_token = request.cookies.get("csrf_token", "")
                header_token = request.headers.get("X-CSRF-Token", "")
                if not cookie_token or not header_token or not secrets.compare_digest(cookie_token, header_token):
                    return JSONResponse(status_code=403, content={"detail": "CSRF token missing or invalid."})
                origin = request.headers.get("Origin")
                if origin and origin.rstrip("/") not in settings.cors_origins:
                    return JSONResponse(status_code=403, content={"detail": "Untrusted request origin."})
        response = await call_next(request)
        return response
