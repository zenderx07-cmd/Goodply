from __future__ import annotations

from datetime import datetime, timedelta, timezone
from uuid import UUID, uuid4

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.security import create_refresh_secret, hash_opaque_token
from app.modules.identity.models import AuthRefreshToken, MembershipRole, OrganizationMembership, Role, User


async def create_refresh_session(
    session: AsyncSession,
    *,
    user_id: UUID,
    organization_id: UUID,
    family_id: UUID | None = None,
) -> tuple[str, UUID]:
    raw_token, token_hash = create_refresh_secret(organization_id)
    family = family_id or uuid4()
    row = AuthRefreshToken(
        organization_id=organization_id,
        user_id=user_id,
        token_hash=token_hash,
        family_id=family,
        expires_at=datetime.now(timezone.utc) + timedelta(days=settings.AUTH_REFRESH_TOKEN_DAYS),
    )
    session.add(row)
    await session.flush()
    return raw_token, family


async def get_membership_roles(session: AsyncSession, membership_id: UUID, organization_id: UUID) -> tuple[list[str], list[str]]:
    role_rows = await session.execute(
        select(Role.slug)
        .join(MembershipRole, MembershipRole.role_id == Role.id)
        .where(MembershipRole.organization_id == organization_id, MembershipRole.membership_id == membership_id)
    )
    roles = sorted(set(role_rows.scalars().all()))
    from app.modules.identity.models import Permission, RolePermission

    permission_rows = await session.execute(
        select(Permission.key)
        .join(RolePermission, RolePermission.permission_id == Permission.id)
        .join(MembershipRole, MembershipRole.role_id == RolePermission.role_id)
        .where(
            MembershipRole.organization_id == organization_id,
            MembershipRole.membership_id == membership_id,
            RolePermission.organization_id == organization_id,
        )
    )
    permissions = sorted(set(permission_rows.scalars().all()))
    return roles, permissions


async def revoke_refresh_family(
    session: AsyncSession,
    *,
    organization_id: UUID,
    family_id: UUID,
    reason: str,
) -> None:
    now = datetime.now(timezone.utc)
    await session.execute(
        update(AuthRefreshToken)
        .where(
            AuthRefreshToken.organization_id == organization_id,
            AuthRefreshToken.family_id == family_id,
        )
        .values(is_revoked=True, revoked_at=now, revocation_reason=reason)
    )


async def user_can_join_invited_org(
    session: AsyncSession, user: User, organization_id: UUID
) -> bool:
    existing = await session.scalar(
        select(OrganizationMembership.id).where(
            OrganizationMembership.organization_id == organization_id,
            OrganizationMembership.user_id == user.id,
        )
    )
    return existing is None


def hash_invitation_secret(raw_token: str) -> str:
    return hash_opaque_token(raw_token)
