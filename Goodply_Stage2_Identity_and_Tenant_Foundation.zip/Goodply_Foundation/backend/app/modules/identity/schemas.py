from __future__ import annotations

import re
from datetime import datetime
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
from typing import Any, Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator

_EMAIL = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")
_SLUG = re.compile(r"^[a-z0-9](?:[a-z0-9-]{1,61}[a-z0-9])$")


class RegisterRequest(BaseModel):
    full_name: str = Field(min_length=2, max_length=120)
    email: str = Field(max_length=320)
    password: str = Field(min_length=12, max_length=128)
    organization_name: str = Field(min_length=2, max_length=200)
    organization_slug: str = Field(min_length=3, max_length=63)

    @field_validator("full_name", "organization_name")
    @classmethod
    def nonblank_names(cls, value: str) -> str:
        value = value.strip()
        if len(value) < 2:
            raise ValueError("Enter at least 2 non-space characters")
        return value

    @field_validator("email")
    @classmethod
    def valid_email(cls, value: str) -> str:
        value = value.strip()
        if not _EMAIL.fullmatch(value):
            raise ValueError("Enter a valid email address")
        return value

    @field_validator("organization_slug")
    @classmethod
    def valid_slug(cls, value: str) -> str:
        value = value.strip().lower()
        if not _SLUG.fullmatch(value):
            raise ValueError("Use 3–63 lowercase letters, numbers or hyphens; no leading/trailing hyphen")
        return value


class LoginRequest(BaseModel):
    organization_slug: str = Field(min_length=3, max_length=63)
    email: str = Field(max_length=320)
    password: str = Field(min_length=1, max_length=128)

    @field_validator("organization_slug")
    @classmethod
    def valid_login_slug(cls, value: str) -> str:
        value = value.strip().lower()
        if not _SLUG.fullmatch(value):
            raise ValueError("Enter a valid organization address")
        return value

    @field_validator("email")
    @classmethod
    def valid_email(cls, value: str) -> str:
        value = value.strip()
        if not _EMAIL.fullmatch(value):
            raise ValueError("Enter a valid email address")
        return value


class AcceptInvitationRequest(BaseModel):
    invitation_token: str = Field(min_length=40, max_length=160)
    full_name: str = Field(min_length=2, max_length=120)
    password: str = Field(min_length=12, max_length=128)

    @field_validator("full_name")
    @classmethod
    def valid_full_name(cls, value: str) -> str:
        value = value.strip()
        if len(value) < 2:
            raise ValueError("Enter at least 2 non-space characters")
        return value


class InvitationCreateRequest(BaseModel):
    email: str = Field(max_length=320)
    role_id: UUID
    branch_ids: list[UUID] = Field(default_factory=list, max_length=100)
    scope_level: Literal["organization", "branches"] = "branches"

    @field_validator("email")
    @classmethod
    def valid_email(cls, value: str) -> str:
        value = value.strip()
        if not _EMAIL.fullmatch(value):
            raise ValueError("Enter a valid email address")
        return value

    @field_validator("branch_ids")
    @classmethod
    def unique_branch_ids(cls, values: list[UUID]) -> list[UUID]:
        if len(values) != len(set(values)):
            raise ValueError("Branch IDs must not contain duplicates")
        return values


class BranchCreateRequest(BaseModel):
    name: str = Field(min_length=2, max_length=150)
    code: str = Field(min_length=1, max_length=30)
    address: str | None = Field(default=None, max_length=500)
    city: str | None = Field(default=None, max_length=120)
    country_code: str | None = Field(default=None, min_length=2, max_length=2)
    timezone: str = Field(default="UTC", min_length=1, max_length=64)
    phone: str | None = Field(default=None, max_length=40)


class UserSummary(BaseModel):
    id: UUID
    email: str
    full_name: str


class OrganizationSummary(BaseModel):
    id: UUID
    name: str
    slug: str
    status: str
    tier: str


class AuthResponse(BaseModel):
    user: UserSummary
    organization: OrganizationSummary
    roles: list[str]
    permissions: list[str]


class BranchRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: UUID
    name: str
    code: str
    address: str | None
    city: str | None
    country_code: str | None
    timezone: str
    phone: str | None
    is_active: bool


class InvitationCreated(BaseModel):
    invitation_id: UUID
    email: str
    expires_at: datetime
    invitation_token: str
    note: str


class ErrorEnvelope(BaseModel):
    detail: str
    code: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
