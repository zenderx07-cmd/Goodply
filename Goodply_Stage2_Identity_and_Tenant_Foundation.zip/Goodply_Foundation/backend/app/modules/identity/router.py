from __future__ import annotations

from datetime import datetime, timedelta, timezone
from uuid import UUID, uuid4

import jwt
from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from sqlalchemy import func, select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.database import bind_tenant_context, get_db_session
from app.core.dependencies import UserContext, get_current_user_context
from app.core.rate_limit import enforce_rate_limit
from app.core.security import (
    create_access_token,
    extract_refresh_organization,
    hash_opaque_token,
    hash_password,
    normalize_email,
    verify_password,
)
from app.modules.identity.access_defaults import seed_default_roles
from app.modules.identity.models import (
    AuditLog,
    AuthRefreshToken,
    Branch,
    InvitationBranchScope,
    MembershipBranchScope,
    MembershipRole,
    Organization,
    OrganizationDirectory,
    OrganizationInvitation,
    OrganizationMembership,
    Role,
    User,
)
from app.modules.identity.schemas import (
    AcceptInvitationRequest,
    AuthResponse,
    LoginRequest,
    OrganizationSummary,
    RegisterRequest,
    UserSummary,
)
from app.modules.identity.service import (
    create_refresh_session,
    get_membership_roles,
    revoke_refresh_family,
    user_can_join_invited_org,
)

router = APIRouter(prefix="/auth", tags=["Authentication & Sessions"])


def _set_auth_cookies(response: Response, access_token: str, refresh_token: str) -> None:
    csrf_token = __import__("secrets").token_urlsafe(32)
    common = {"secure": settings.secure_cookies, "samesite": "lax", "path": "/"}
    if getattr(settings, "COOKIE_DOMAIN", None):
        common["domain"] = settings.COOKIE_DOMAIN
    response.set_cookie(
        "access_token", access_token,
        max_age=settings.AUTH_ACCESS_TOKEN_MINUTES * 60,
        httponly=True,
        **common,
    )
    response.set_cookie(
        "refresh_token", refresh_token,
        max_age=settings.AUTH_REFRESH_TOKEN_DAYS * 24 * 60 * 60,
        httponly=True,
        **common,
    )
    response.set_cookie(
        "csrf_token", csrf_token,
        max_age=settings.AUTH_REFRESH_TOKEN_DAYS * 24 * 60 * 60,
        httponly=False,
        **common,
    )


def _clear_auth_cookies(response: Response) -> None:
    common = {"secure": settings.secure_cookies, "samesite": "lax", "path": "/"}
    if getattr(settings, "COOKIE_DOMAIN", None):
        common["domain"] = settings.COOKIE_DOMAIN
    for name in ("access_token", "refresh_token", "csrf_token"):
        response.delete_cookie(name, **common)


async def _response_payload(
    session: AsyncSession,
    user: User,
    organization: Organization,
    membership: OrganizationMembership,
) -> AuthResponse:
    roles, permissions = await get_membership_roles(session, membership.id, organization.id)
    return AuthResponse(
        user=UserSummary(id=user.id, email=user.email, full_name=user.full_name),
        organization=OrganizationSummary(
            id=organization.id,
            name=organization.name,
            slug=organization.slug,
            status=organization.status,
            tier=organization.tier,
        ),
        roles=roles,
        permissions=permissions,
    )


def _add_audit(
    session: AsyncSession,
    organization_id: UUID,
    actor_user_id: UUID | None,
    action: str,
    entity_type: str,
    entity_id: UUID | None = None,
    metadata: dict | None = None,
) -> None:
    session.add(AuditLog(
        organization_id=organization_id,
        actor_user_id=actor_user_id,
        action=action,
        entity_type=entity_type,
        entity_id=str(entity_id) if entity_id else None,
        metadata_json=metadata or {},
    ))


async def _issue_new_family(
    session: AsyncSession, response: Response, user: User, organization: Organization
) -> None:
    refresh_token, family_id = await create_refresh_session(
        session,
        user_id=user.id,
        organization_id=organization.id,
    )
    access_token = create_access_token(user.id, organization.id, family_id)
    _set_auth_cookies(response, access_token, refresh_token)


@router.post("/register", response_model=AuthResponse, status_code=status.HTTP_201_CREATED)
async def register(
    payload: RegisterRequest,
    request: Request,
    response: Response,
    session: AsyncSession = Depends(get_db_session),
) -> AuthResponse:
    await enforce_rate_limit(
        request, bucket="register", identity=request.client.host if request.client else "unknown",
        limit=5, window_seconds=86_400,
    )
    email_normalized = normalize_email(payload.email)
    existing_user = await session.scalar(select(func.lookup_user_id_by_email(email_normalized)))
    existing_org = await session.scalar(select(OrganizationDirectory.organization_id).where(OrganizationDirectory.slug == payload.organization_slug))
    if existing_user:
        raise HTTPException(status_code=409, detail="An account already exists for this email address.")
    if existing_org:
        raise HTTPException(status_code=409, detail="That organization address is already in use.")

    organization_id = uuid4()
    user_id = uuid4()
    await bind_tenant_context(session, organization_id, user_id)
    user = User(
        id=user_id,
        email=payload.email,
        email_normalized=email_normalized,
        password_hash=hash_password(payload.password),
        full_name=payload.full_name.strip(),
    )
    organization = Organization(id=organization_id, name=payload.organization_name.strip(), slug=payload.organization_slug)
    session.add_all([user, organization])
    try:
        await session.flush()
    except IntegrityError:
        await session.rollback()
        raise HTTPException(status_code=409, detail="The email or organization address is already in use.") from None
    await bind_tenant_context(session, organization.id, user.id)

    branch = Branch(
        organization_id=organization.id,
        name="Head Office",
        code="HQ",
        timezone="UTC",
    )
    membership = OrganizationMembership(
        organization_id=organization.id,
        user_id=user.id,
        status="active",
        scope_level="organization",
        job_title="Owner",
    )
    session.add_all([branch, membership])
    await session.flush()

    roles = await seed_default_roles(session, organization.id)
    session.add(MembershipRole(
        organization_id=organization.id,
        membership_id=membership.id,
        role_id=roles["owner"].id,
    ))
    _add_audit(session, organization.id, user.id, "organization.created", "organization", organization.id)
    _add_audit(session, organization.id, user.id, "auth.registered", "user", user.id)
    await _issue_new_family(session, response, user, organization)
    await session.commit()
    return await _response_payload(session, user, organization, membership)


@router.post("/login", response_model=AuthResponse)
async def login(
    payload: LoginRequest,
    request: Request,
    response: Response,
    session: AsyncSession = Depends(get_db_session),
) -> AuthResponse:
    client_ip = request.client.host if request.client else "unknown"
    await enforce_rate_limit(
        request, bucket="login_pair", identity=f"{client_ip}:{normalize_email(payload.email)}:{payload.organization_slug.lower()}",
        limit=10, window_seconds=900,
    )
    await enforce_rate_limit(
        request, bucket="login_ip", identity=client_ip,
        limit=60, window_seconds=900,
    )
    directory = await session.scalar(
        select(OrganizationDirectory).where(OrganizationDirectory.slug == payload.organization_slug.strip().lower())
    )
    if directory is None:
        raise HTTPException(status_code=401, detail="Invalid organization, email or password.")
    await bind_tenant_context(session, directory.organization_id)
    user = await session.scalar(
        select(User)
        .join(OrganizationMembership, OrganizationMembership.user_id == User.id)
        .where(
            OrganizationMembership.organization_id == directory.organization_id,
            OrganizationMembership.status == "active",
            User.email_normalized == normalize_email(payload.email),
        )
    )
    # User row-level security now exposes only members of the selected tenant.
    if user is None or not user.is_active or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid organization, email or password.")
    await bind_tenant_context(session, directory.organization_id, user.id)
    organization = await session.scalar(select(Organization).where(Organization.id == directory.organization_id))
    if organization is None or organization.status not in {"active", "trial"}:
        raise HTTPException(status_code=403, detail="This organization is not currently available.")
    membership = await session.scalar(
        select(OrganizationMembership).where(
            OrganizationMembership.organization_id == organization.id,
            OrganizationMembership.user_id == user.id,
            OrganizationMembership.status == "active",
        )
    )
    if membership is None:
        raise HTTPException(status_code=401, detail="Invalid organization, email or password.")
    user.last_login_at = datetime.now(timezone.utc)
    _add_audit(session, organization.id, user.id, "auth.login", "user", user.id)
    await _issue_new_family(session, response, user, organization)
    await session.commit()
    return await _response_payload(session, user, organization, membership)


@router.post("/refresh", response_model=AuthResponse)
async def refresh(
    request: Request,
    response: Response,
    session: AsyncSession = Depends(get_db_session),
) -> AuthResponse:
    raw_token = request.cookies.get("refresh_token")
    try:
        organization_id = extract_refresh_organization(raw_token or "")
    except ValueError:
        _clear_auth_cookies(response)
        raise HTTPException(status_code=401, detail="Refresh session is invalid.") from None

    await bind_tenant_context(session, organization_id)
    token_hash = hash_opaque_token(raw_token or "")
    token_row = await session.scalar(
        select(AuthRefreshToken)
        .where(
            AuthRefreshToken.organization_id == organization_id,
            AuthRefreshToken.token_hash == token_hash,
        )
        .with_for_update()
    )
    if token_row is None:
        _clear_auth_cookies(response)
        raise HTTPException(status_code=401, detail="Refresh session is invalid.")

    now = datetime.now(timezone.utc)
    if token_row.used_at is not None or token_row.is_revoked:
        await revoke_refresh_family(
            session, organization_id=organization_id, family_id=token_row.family_id, reason="reuse_detected"
        )
        await session.commit()
        _clear_auth_cookies(response)
        raise HTTPException(status_code=401, detail="Refresh token reuse detected; sign in again.")
    if token_row.expires_at <= now:
        await revoke_refresh_family(
            session, organization_id=organization_id, family_id=token_row.family_id, reason="expired"
        )
        await session.commit()
        _clear_auth_cookies(response)
        raise HTTPException(status_code=401, detail="Refresh session expired.")

    user = await session.scalar(select(User).where(User.id == token_row.user_id, User.is_active.is_(True)))
    organization = await session.scalar(
        select(Organization).where(Organization.id == organization_id, Organization.status.in_(["active", "trial"]))
    )
    membership = await session.scalar(
        select(OrganizationMembership).where(
            OrganizationMembership.organization_id == organization_id,
            OrganizationMembership.user_id == token_row.user_id,
            OrganizationMembership.status == "active",
        )
    )
    if user is None or organization is None or membership is None:
        await revoke_refresh_family(
            session, organization_id=organization_id, family_id=token_row.family_id, reason="account_or_membership_inactive"
        )
        await session.commit()
        _clear_auth_cookies(response)
        raise HTTPException(status_code=401, detail="Account or membership is no longer active.")

    new_raw, new_hash = __import__("app.core.security", fromlist=["create_refresh_secret"]).create_refresh_secret(organization_id)
    new_row = AuthRefreshToken(
        organization_id=organization_id,
        user_id=user.id,
        token_hash=new_hash,
        family_id=token_row.family_id,
        expires_at=now + timedelta(days=settings.AUTH_REFRESH_TOKEN_DAYS),
    )
    session.add(new_row)
    await session.flush()
    token_row.used_at = now
    token_row.is_revoked = True
    token_row.revoked_at = now
    token_row.revocation_reason = "rotated"
    token_row.replaced_by_token_id = new_row.id
    _add_audit(session, organization_id, user.id, "auth.refresh", "session_family", token_row.family_id)
    access_token = create_access_token(user.id, organization_id, token_row.family_id)
    _set_auth_cookies(response, access_token, new_raw)
    await session.commit()
    return await _response_payload(session, user, organization, membership)


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
async def logout(
    request: Request,
    response: Response,
    context: UserContext = Depends(get_current_user_context),
    session: AsyncSession = Depends(get_db_session),
) -> Response:
    await bind_tenant_context(session, context.organization.id, context.user.id)
    await revoke_refresh_family(
        session,
        organization_id=context.organization.id,
        family_id=context.family_id,
        reason="user_logout",
    )
    _add_audit(session, context.organization.id, context.user.id, "auth.logout", "session_family", context.family_id)
    await session.commit()
    _clear_auth_cookies(response)
    response.status_code = status.HTTP_204_NO_CONTENT
    return response


@router.get("/me", response_model=AuthResponse)
async def me(context: UserContext = Depends(get_current_user_context), session: AsyncSession = Depends(get_db_session)) -> AuthResponse:
    return await _response_payload(session, context.user, context.organization, context.membership)


@router.post("/invitations/accept", response_model=AuthResponse, status_code=status.HTTP_201_CREATED)
async def accept_invitation(
    payload: AcceptInvitationRequest,
    response: Response,
    session: AsyncSession = Depends(get_db_session),
) -> AuthResponse:
    try:
        organization_id = extract_refresh_organization(payload.invitation_token)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invitation token is invalid or expired.") from None
    await bind_tenant_context(session, organization_id)
    invitation = await session.scalar(
        select(OrganizationInvitation)
        .where(
            OrganizationInvitation.organization_id == organization_id,
            OrganizationInvitation.token_hash == hash_opaque_token(payload.invitation_token),
        )
        .with_for_update()
    )
    now = datetime.now(timezone.utc)
    if invitation is None or invitation.status != "pending" or invitation.expires_at <= now:
        raise HTTPException(status_code=400, detail="Invitation token is invalid or expired.")

    organization = await session.scalar(
        select(Organization).where(Organization.id == organization_id)
    )
    if organization is None or organization.status not in {"active", "trial"}:
        raise HTTPException(status_code=403, detail="This organization is not currently available.")

    existing_user_id = await session.scalar(
        select(func.lookup_user_id_by_email(invitation.email_normalized))
    )
    if existing_user_id is None:
        user = User(
            id=uuid4(),
            email=invitation.email_normalized,
            email_normalized=invitation.email_normalized,
            password_hash=hash_password(payload.password),
            full_name=payload.full_name.strip(),
        )
        await bind_tenant_context(session, organization_id, user.id)
        session.add(user)
        await session.flush()
    else:
        await bind_tenant_context(session, organization_id, existing_user_id)
        user = await session.scalar(select(User).where(User.id == existing_user_id))
        if user is None or not user.is_active or not verify_password(payload.password, user.password_hash):
            raise HTTPException(status_code=401, detail="Use the existing account password to accept this invitation.")

    if not await user_can_join_invited_org(session, user, organization_id):
        raise HTTPException(status_code=409, detail="This user is already a member of the organization.")
    membership = OrganizationMembership(
        organization_id=organization_id,
        user_id=user.id,
        status="active",
        scope_level=invitation.scope_level,
    )
    session.add(membership)
    await session.flush()
    session.add(MembershipRole(
        organization_id=organization_id,
        membership_id=membership.id,
        role_id=invitation.role_id,
    ))
    branch_scopes = await session.execute(
        select(InvitationBranchScope.branch_id).where(
            InvitationBranchScope.organization_id == organization_id,
            InvitationBranchScope.invitation_id == invitation.id,
        )
    )
    for branch_id in branch_scopes.scalars().all():
        session.add(MembershipBranchScope(
            organization_id=organization_id,
            membership_id=membership.id,
            branch_id=branch_id,
        ))
    invitation.status = "accepted"
    invitation.accepted_at = now
    await bind_tenant_context(session, organization_id, user.id)
    _add_audit(session, organization_id, user.id, "organization.invitation_accepted", "organization_membership", membership.id)
    await _issue_new_family(session, response, user, organization)
    await session.commit()
    return await _response_payload(session, user, organization, membership)
