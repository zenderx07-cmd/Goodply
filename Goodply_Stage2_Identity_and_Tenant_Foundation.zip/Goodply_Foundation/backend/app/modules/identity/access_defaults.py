from __future__ import annotations

from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.modules.identity.models import Permission, Role, RolePermission

# These are organization-level templates. Owners can subsequently create custom
# roles and adjust permissions through the access-control module.
ROLE_TEMPLATES: dict[str, tuple[str, str, set[str]]] = {
    "owner": ("Organization Owner", "Full organization control", {"*"}),
    "administrator": ("Organization Administrator", "Administrative access, excluding organization deletion", set()),
    "general_manager": ("General Manager", "Organization-wide operations and reporting", set()),
    "branch_manager": ("Branch Manager", "Management within assigned branches", {
        "organization:read", "branches:read", "members:read", "departments:read", "analytics:read",
        "reviews:read", "reviews:respond", "crm:read", "crm:write", "inbox:read", "inbox:reply",
        "tickets:read", "tickets:manage", "tasks:read", "tasks:manage", "sales:read", "sales:manage",
        "marketing:read", "inventory:read", "inventory:write", "workforce:read", "workforce:manage",
        "integrations:read",
    }),
    "department_manager": ("Department Manager", "Department-level team and operational management", {
        "organization:read", "branches:read", "members:read", "departments:read", "analytics:read",
        "tickets:read", "tickets:manage", "tasks:read", "tasks:manage", "inventory:read", "inventory:write",
        "workforce:read", "workforce:manage", "crm:read", "inbox:read",
    }),
    "supervisor": ("Supervisor", "Supervisory access to assigned team workflows", {
        "organization:read", "branches:read", "members:read", "departments:read", "tasks:read", "tasks:manage",
        "tickets:read", "tickets:manage", "workforce:read", "crm:read", "inbox:read", "inbox:reply",
        "reviews:read",
    }),
    "customer_support_agent": ("Customer Support Agent", "Assigned customer conversations and tickets", {
        "organization:read", "branches:read", "crm:read", "inbox:read", "inbox:reply", "tickets:read", "tickets:manage",
        "reviews:read",
    }),
    "sales_representative": ("Sales Representative", "Lead, customer and deal management", {
        "organization:read", "branches:read", "crm:read", "crm:write", "sales:read", "sales:manage", "tasks:read",
    }),
    "employee": ("Employee", "Basic access to assigned work", {
        "organization:read", "branches:read", "tasks:read", "tickets:read",
    }),
    "auditor": ("Auditor / Read-only User", "Read-only access to permitted organization records", set()),
}

READ_ONLY_PREFIXES = ("organization:read", "branches:read", "members:read", "roles:read", "departments:read", "audit:read", "analytics:read", "reviews:read", "crm:read", "inbox:read", "tickets:read", "tasks:read", "sales:read", "marketing:read", "inventory:read", "workforce:read", "integrations:read")


async def seed_default_roles(session: AsyncSession, organization_id: UUID) -> dict[str, Role]:
    permission_rows = (await session.execute(select(Permission))).scalars().all()
    permission_by_key = {permission.key: permission for permission in permission_rows}
    all_keys = set(permission_by_key)
    role_map: dict[str, Role] = {}

    for slug, (name, description, configured) in ROLE_TEMPLATES.items():
        role = Role(
            organization_id=organization_id,
            name=name,
            slug=slug,
            description=description,
            is_system=True,
        )
        session.add(role)
        await session.flush()
        if slug == "owner":
            selected_keys = all_keys
        elif slug == "administrator":
            selected_keys = all_keys - {"organization:delete"}
        elif slug == "general_manager":
            selected_keys = all_keys - {"organization:delete", "roles:manage", "settings:manage"}
        elif slug == "auditor":
            selected_keys = set(READ_ONLY_PREFIXES)
        else:
            selected_keys = configured
        for key in sorted(selected_keys & all_keys):
            session.add(RolePermission(
                organization_id=organization_id,
                role_id=role.id,
                permission_id=permission_by_key[key].id,
            ))
        role_map[slug] = role
    await session.flush()
    return role_map
