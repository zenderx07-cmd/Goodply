import asyncio
import time
from typing import Any

from fastapi import APIRouter, Response, status
from sqlalchemy import text

from app.core.config import settings
from app.core.database import get_engine

router = APIRouter(prefix="/health", tags=["system"])


async def check_database() -> dict[str, Any]:
    if not settings.DATABASE_URL:
        return {"status": "not_configured"}
    started = time.perf_counter()
    try:
        async with get_engine().connect() as connection:
            await asyncio.wait_for(
                connection.execute(text("SELECT 1")),
                timeout=settings.HEALTH_CHECK_TIMEOUT_SECONDS,
            )
        return {"status": "ok", "latency_ms": round((time.perf_counter() - started) * 1000, 2)}
    except Exception:
        # Do not return driver exceptions, hostnames, credentials, or SQL to callers.
        return {"status": "unavailable"}


async def check_redis() -> dict[str, Any]:
    if not settings.REDIS_URL:
        return {"status": "not_configured"}
    started = time.perf_counter()
    client = None
    try:
        from redis.asyncio import Redis

        client = Redis.from_url(
            settings.REDIS_URL,
            socket_connect_timeout=settings.HEALTH_CHECK_TIMEOUT_SECONDS,
            socket_timeout=settings.HEALTH_CHECK_TIMEOUT_SECONDS,
            decode_responses=True,
        )
        await asyncio.wait_for(client.ping(), timeout=settings.HEALTH_CHECK_TIMEOUT_SECONDS)
        return {"status": "ok", "latency_ms": round((time.perf_counter() - started) * 1000, 2)}
    except Exception:
        return {"status": "unavailable"}
    finally:
        if client is not None:
            try:
                await client.aclose()
            except Exception:
                pass


@router.get("/live", summary="Process liveness")
async def liveness() -> dict[str, str]:
    return {"status": "ok"}


@router.get("/ready", summary="Dependency readiness")
async def readiness(response: Response) -> dict[str, Any]:
    database, redis = await asyncio.gather(check_database(), check_redis())
    checks = {"database": database, "redis": redis}
    ready = all(check["status"] == "ok" for check in checks.values())
    if not ready:
        response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE
    return {"status": "ready" if ready else "not_ready", "checks": checks}
