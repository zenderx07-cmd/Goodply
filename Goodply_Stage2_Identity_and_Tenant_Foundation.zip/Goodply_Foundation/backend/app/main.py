from contextlib import asynccontextmanager
from collections.abc import AsyncIterator
import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.core.database import dispose_database, verify_runtime_database_role
from app.modules.system.health import router as health_router
from app.modules.identity.router import router as identity_router
from app.modules.identity.csrf import DoubleSubmitCSRFMiddleware
from app.modules.organizations.router import router as organizations_router

logging.basicConfig(level=settings.LOG_LEVEL.upper())


@asynccontextmanager
async def lifespan(_: FastAPI) -> AsyncIterator[None]:
    if settings.ENVIRONMENT == "production":
        settings.validate_production_configuration()
    if settings.DATABASE_URL:
        await verify_runtime_database_role()
    yield
    await dispose_database()


def create_app() -> FastAPI:
    application = FastAPI(
        title=settings.PROJECT_NAME,
        description="Goodply enterprise business management platform API",
        version="0.1.0",
        docs_url=f"{settings.API_V1_STR}/docs",
        redoc_url=f"{settings.API_V1_STR}/redoc",
        openapi_url=f"{settings.API_V1_STR}/openapi.json",
        lifespan=lifespan,
    )
    application.add_middleware(DoubleSubmitCSRFMiddleware)
    application.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type", "X-CSRF-Token", "X-Request-ID"],
    )
    application.include_router(health_router, prefix=settings.API_V1_STR)
    application.include_router(identity_router, prefix=settings.API_V1_STR)
    application.include_router(organizations_router, prefix=settings.API_V1_STR)
    return application


app = create_app()
