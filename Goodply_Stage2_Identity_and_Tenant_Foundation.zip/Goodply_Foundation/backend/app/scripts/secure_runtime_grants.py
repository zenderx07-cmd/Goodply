from __future__ import annotations

import asyncio
import re

import asyncpg

from app.core.config import settings


_ALLOWED_ROLE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,62}$")
_READ_ONLY_TABLES = (
    "organization_directory",
    "permissions",
)


async def main() -> None:
    migration_url = settings.MIGRATION_DATABASE_URL
    role = settings.DB_APP_ROLE
    if not migration_url:
        raise RuntimeError("MIGRATION_DATABASE_URL is required to secure runtime database grants")
    if not _ALLOWED_ROLE.fullmatch(role):
        raise RuntimeError("DB_APP_ROLE must be a simple PostgreSQL identifier")

    driver_url = migration_url.replace("postgresql+asyncpg://", "postgresql://", 1)
    connection = await asyncpg.connect(driver_url)
    try:
        for table in _READ_ONLY_TABLES:
            await connection.execute(
                f'REVOKE INSERT, UPDATE, DELETE ON TABLE public."{table}" FROM "{role}"'
            )
        await connection.execute(
            f'REVOKE ALL PRIVILEGES ON TABLE public."user_identity_directory" FROM "{role}"'
        )
        await connection.execute(
            f'REVOKE UPDATE, DELETE ON TABLE public."audit_logs" FROM "{role}"'
        )
        await connection.execute(
            f'REVOKE ALL PRIVILEGES ON TABLE public."alembic_version" FROM "{role}"'
        )
        await connection.execute(
            f'GRANT EXECUTE ON FUNCTION public.lookup_user_id_by_email(text) TO "{role}"'
        )
    finally:
        await connection.close()


if __name__ == "__main__":
    asyncio.run(main())
