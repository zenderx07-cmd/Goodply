from __future__ import annotations

import hashlib

from fastapi import HTTPException, Request

from app.core.config import settings


LUA_INCREMENT_WITH_TTL = """
local count = redis.call('INCR', KEYS[1])
if count == 1 then redis.call('EXPIRE', KEYS[1], ARGV[1]) end
local ttl = redis.call('TTL', KEYS[1])
return {count, ttl}
"""


def _key(bucket: str, identity: str) -> str:
    digest = hashlib.sha256(f"{settings.auth_signing_key}:{identity}".encode("utf-8")).hexdigest()
    return f"goodply:ratelimit:{bucket}:{digest}"


async def enforce_rate_limit(
    request: Request,
    *,
    bucket: str,
    identity: str,
    limit: int,
    window_seconds: int,
) -> None:
    """Rate limit authentication entry points; do not silently bypass configured Redis."""
    if not settings.REDIS_URL:
        if settings.ENVIRONMENT in {"staging", "production"}:
            raise HTTPException(status_code=503, detail="Authentication rate limiting is unavailable.")
        return

    try:
        from redis.asyncio import Redis
    except ImportError:
        raise HTTPException(status_code=503, detail="Authentication rate limiting service is unavailable.") from None

    client = Redis.from_url(
        settings.REDIS_URL,
        socket_connect_timeout=1.5,
        socket_timeout=1.5,
        decode_responses=True,
    )
    try:
        count, ttl = await client.eval(
            LUA_INCREMENT_WITH_TTL,
            1,
            _key(bucket, identity),
            window_seconds,
        )
    except Exception:
        if settings.ENVIRONMENT in {"staging", "production"}:
            raise HTTPException(status_code=503, detail="Authentication rate limiting is unavailable.") from None
        raise HTTPException(status_code=503, detail="Authentication rate limiting service is unavailable.") from None
    finally:
        await client.aclose()

    if int(count) > limit:
        raise HTTPException(
            status_code=429,
            detail="Too many attempts. Please try again later.",
            headers={"Retry-After": str(max(1, int(ttl)))},
        )
