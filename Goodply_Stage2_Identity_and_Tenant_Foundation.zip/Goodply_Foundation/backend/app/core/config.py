from functools import lru_cache
from typing import Literal
import secrets

from pydantic import Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


_DEV_AUTH_SECRET = secrets.token_urlsafe(64)


class Settings(BaseSettings):
    """Environment-backed configuration; production secrets have no defaults."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
        extra="ignore",
    )

    PROJECT_NAME: str = "Goodply"
    ENVIRONMENT: Literal["development", "test", "staging", "production"] = "development"
    API_V1_STR: str = "/api/v1"
    BACKEND_CORS_ORIGINS: str = "http://localhost:3000"
    DATABASE_URL: str | None = None  # Restricted non-superuser runtime connection.
    MIGRATION_DATABASE_URL: str | None = None  # Privileged connection used only by Alembic/release job.
    DB_APP_ROLE: str = "goodply_app"
    REDIS_URL: str | None = None
    COOKIE_DOMAIN: str | None = None
    SECRET_KEY: SecretStr | None = None
    AUTH_ACCESS_TOKEN_MINUTES: int = Field(default=15, ge=5, le=60)
    AUTH_REFRESH_TOKEN_DAYS: int = Field(default=30, ge=1, le=90)
    DATABASE_POOL_SIZE: int = Field(default=5, ge=1, le=100)
    DATABASE_MAX_OVERFLOW: int = Field(default=10, ge=0, le=200)
    LOG_LEVEL: str = "INFO"
    HEALTH_CHECK_TIMEOUT_SECONDS: float = Field(default=2.0, gt=0, le=10)

    @property
    def cors_origins(self) -> list[str]:
        return [origin.strip().rstrip("/") for origin in self.BACKEND_CORS_ORIGINS.split(",") if origin.strip()]

    @property
    def auth_signing_key(self) -> str:
        if self.SECRET_KEY is not None:
            value = self.SECRET_KEY.get_secret_value()
            if len(value) < 32:
                raise RuntimeError("SECRET_KEY must contain at least 32 characters")
            return value
        if self.ENVIRONMENT in {"development", "test"}:
            return _DEV_AUTH_SECRET
        raise RuntimeError("SECRET_KEY must be configured outside development/test")

    @property
    def secure_cookies(self) -> bool:
        return self.ENVIRONMENT in {"staging", "production"}

    def validate_production_configuration(self) -> None:
        missing: list[str] = []
        if not self.DATABASE_URL:
            missing.append("DATABASE_URL")
        if not self.REDIS_URL:
            missing.append("REDIS_URL")
        if self.SECRET_KEY is None or len(self.SECRET_KEY.get_secret_value()) < 32:
            missing.append("SECRET_KEY (at least 32 characters)")
        if missing:
            raise RuntimeError("Missing or invalid production configuration: " + ", ".join(missing))


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
