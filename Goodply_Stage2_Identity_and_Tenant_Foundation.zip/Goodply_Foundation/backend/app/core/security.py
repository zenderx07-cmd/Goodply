from __future__ import annotations

import hashlib
import secrets
from datetime import datetime, timedelta, timezone
from uuid import UUID

import jwt
from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError, VerifyMismatchError

from app.core.config import settings

_password_hasher = PasswordHasher(time_cost=3, memory_cost=65_536, parallelism=2)


def normalize_email(email: str) -> str:
    return email.strip().casefold()


def hash_password(password: str) -> str:
    if len(password) < 12:
        raise ValueError("Password must contain at least 12 characters")
    if len(password) > 128:
        raise ValueError("Password cannot exceed 128 characters")
    return _password_hasher.hash(password)


def verify_password(password: str, password_hash: str) -> bool:
    try:
        return _password_hasher.verify(password_hash, password)
    except (VerifyMismatchError, VerificationError, InvalidHashError):
        return False


def hash_opaque_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def create_refresh_secret(organization_id: UUID) -> tuple[str, str]:
    """Return an opaque token prefixed with the tenant UUID and its SHA-256 hash."""
    raw = f"{organization_id}.{secrets.token_urlsafe(48)}"
    return raw, hash_opaque_token(raw)


def extract_refresh_organization(token: str) -> UUID:
    try:
        prefix, secret = token.split(".", 1)
        if not secret or len(secret) < 32:
            raise ValueError
        return UUID(prefix)
    except (ValueError, AttributeError) as exc:
        raise ValueError("Malformed refresh token") from exc


def create_access_token(user_id: UUID, organization_id: UUID, family_id: UUID) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": str(user_id),
        "org": str(organization_id),
        "sid": str(family_id),
        "iat": now,
        "nbf": now,
        "exp": now + timedelta(minutes=settings.AUTH_ACCESS_TOKEN_MINUTES),
        "iss": "goodply-api",
        "aud": "goodply-app",
        "typ": "access",
    }
    return jwt.encode(payload, settings.auth_signing_key, algorithm="HS256")


def decode_access_token(token: str) -> dict:
    claims = jwt.decode(
        token,
        settings.auth_signing_key,
        algorithms=["HS256"],
        audience="goodply-app",
        issuer="goodply-api",
        options={"require": ["sub", "org", "sid", "iat", "nbf", "exp", "iss", "aud"]},
    )
    if claims.get("typ") != "access":
        raise jwt.InvalidTokenError("Unexpected token type")
    return claims
