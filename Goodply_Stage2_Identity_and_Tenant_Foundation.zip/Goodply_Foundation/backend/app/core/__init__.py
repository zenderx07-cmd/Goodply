"""Shared backend infrastructure."""
