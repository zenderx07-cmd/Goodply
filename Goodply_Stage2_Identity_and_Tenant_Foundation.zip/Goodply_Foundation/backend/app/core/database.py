from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Any
from uuid import UUID

from sqlalchemy import MetaData, event, text
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase, Session

from app.core.config import settings

NAMING_CONVENTION = {
    "ix": "ix_%(table_name)s_%(column_0_name)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}


class Base(DeclarativeBase):
    metadata = MetaData(naming_convention=NAMING_CONVENTION)


_engine: AsyncEngine | None = None
_session_factory: async_sessionmaker[AsyncSession] | None = None


def get_engine() -> AsyncEngine:
    """Create the async PostgreSQL engine lazily."""
    global _engine, _session_factory
    if _engine is None:
        if not settings.DATABASE_URL:
            raise RuntimeError("DATABASE_URL is not configured")
        if not settings.DATABASE_URL.startswith("postgresql+asyncpg://"):
            raise RuntimeError("DATABASE_URL must use postgresql+asyncpg://")
        _engine = create_async_engine(
            settings.DATABASE_URL,
            pool_pre_ping=True,
            pool_size=settings.DATABASE_POOL_SIZE,
            max_overflow=settings.DATABASE_MAX_OVERFLOW,
            pool_recycle=1800,
        )
        _session_factory = async_sessionmaker(
            _engine,
            expire_on_commit=False,
            autoflush=False,
        )
    return _engine


def get_session_factory() -> async_sessionmaker[AsyncSession]:
    get_engine()
    if _session_factory is None:
        raise RuntimeError("Database session factory was not initialized")
    return _session_factory


def validate_runtime_role(
    role_name: str,
    is_superuser: bool,
    bypass_rls: bool,
    expected_role: str,
) -> None:
    """Fail closed if the API DB connection is not the dedicated restricted role."""
    if role_name != expected_role:
        raise RuntimeError(
            f"DATABASE_URL connected as {role_name!r}; expected the restricted role {expected_role!r}"
        )
    if is_superuser or bypass_rls:
        raise RuntimeError(
            "The Goodply API database role must be NOSUPERUSER and NOBYPASSRLS"
        )


async def verify_runtime_database_role() -> None:
    """Verify PostgreSQL role attributes before serving API requests."""
    if not settings.DATABASE_URL:
        return
    async with get_engine().connect() as connection:
        result = await connection.execute(text(
            "SELECT rolname, rolsuper, rolbypassrls "
            "FROM pg_roles WHERE rolname = current_user"
        ))
        row = result.mappings().one_or_none()
    if row is None:
        raise RuntimeError("Unable to identify the current PostgreSQL runtime role")
    validate_runtime_role(
        role_name=row["rolname"],
        is_superuser=bool(row["rolsuper"]),
        bypass_rls=bool(row["rolbypassrls"]),
        expected_role=settings.DB_APP_ROLE,
    )


@event.listens_for(Session, "after_begin")
def _apply_tenant_context(
    session: Session, transaction: Any, connection: Any
) -> None:
    """Reapply tenant/user GUCs for every new transaction, including after commit.

    Values are transaction-local (`set_config(..., true)`), so a pooled connection
    cannot carry one request's tenant context into the next transaction.
    """
    context = session.info.get("goodply_tenant_context")
    if not context:
        return
    connection.execute(
        text("SELECT set_config('app.current_tenant_id', :tenant_id, true)"),
        {"tenant_id": str(context["tenant_id"])},
    )
    connection.execute(
        text("SELECT set_config('app.current_user_id', :user_id, true)"),
        {"user_id": str(context["user_id"]) if context.get("user_id") else ""},
    )


async def bind_tenant_context(
    session: AsyncSession, tenant_id: UUID, user_id: UUID | None = None
) -> None:
    """Bind the request's tenant context and apply it to an already-open transaction."""
    session.info["goodply_tenant_context"] = {
        "tenant_id": tenant_id,
        "user_id": user_id,
    }
    if session.in_transaction():
        await session.execute(
            text("SELECT set_config('app.current_tenant_id', :tenant_id, true)"),
            {"tenant_id": str(tenant_id)},
        )
        await session.execute(
            text("SELECT set_config('app.current_user_id', :user_id, true)"),
            {"user_id": str(user_id) if user_id is not None else ""},
        )


async def clear_tenant_context(session: AsyncSession) -> None:
    session.info.pop("goodply_tenant_context", None)
    if session.in_transaction():
        await session.execute(
            text("SELECT set_config('app.current_tenant_id', '', true), "
                 "set_config('app.current_user_id', '', true)")
        )


async def get_db_session() -> AsyncIterator[AsyncSession]:
    factory = get_session_factory()
    async with factory() as session:
        try:
            yield session
        finally:
            session.info.pop("goodply_tenant_context", None)


async def dispose_database() -> None:
    global _engine, _session_factory
    if _engine is not None:
        await _engine.dispose()
    _engine = None
    _session_factory = None
