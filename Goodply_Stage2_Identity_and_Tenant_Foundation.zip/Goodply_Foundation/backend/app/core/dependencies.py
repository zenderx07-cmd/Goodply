from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from uuid import UUID

import jwt
from fastapi import Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import bind_tenant_context, get_db_session
from app.core.security import decode_access_token
from app.modules.identity.models import (
    AuthRefreshToken,
    Branch,
    MembershipBranchScope,
    MembershipRole,
    Organization,
    OrganizationMembership,
    Permission,
    Role,
    RolePermission,
    User,
)


@dataclass(frozen=True)
class UserContext:
    user: User
    organization: Organization
    membership: OrganizationMembership
    roles: tuple[str, ...]
    permissions: frozenset[str]
    branch_ids: frozenset[UUID]
    family_id: UUID

    @property
    def organization_wide(self) -> bool:
        return self.membership.scope_level == "organization"


def _unauthorized() -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Authentication is required or the session is no longer valid.",
        headers={"WWW-Authenticate": "Bearer"},
    )


async def get_current_user_context(
    request: Request,
    session: AsyncSession = Depends(get_db_session),
) -> UserContext:
    access_token = request.cookies.get("access_token")
    authorization = request.headers.get("Authorization", "")
    if authorization.lower().startswith("bearer "):
        access_token = authorization[7:].strip()
    if not access_token:
        raise _unauthorized()

    try:
        payload = decode_access_token(access_token)
        user_id = UUID(payload["sub"])
        organization_id = UUID(payload["org"])
        family_id = UUID(payload["sid"])
    except (jwt.PyJWTError, KeyError, TypeError, ValueError):
        raise _unauthorized() from None

    await bind_tenant_context(session, organization_id, user_id)
    now = datetime.now(timezone.utc)
    active_family_token = await session.scalar(
        select(AuthRefreshToken.id)
        .where(
            AuthRefreshToken.organization_id == organization_id,
            AuthRefreshToken.family_id == family_id,
            AuthRefreshToken.is_revoked.is_(False),
            AuthRefreshToken.expires_at > now,
        )
        .limit(1)
    )
    if active_family_token is None:
        raise _unauthorized()

    user = await session.scalar(select(User).where(User.id == user_id, User.is_active.is_(True)))
    membership = await session.scalar(
        select(OrganizationMembership).where(
            OrganizationMembership.organization_id == organization_id,
            OrganizationMembership.user_id == user_id,
            OrganizationMembership.status == "active",
        )
    )
    organization = await session.scalar(
        select(Organization).where(Organization.id == organization_id, Organization.status.in_(["active", "trial"]))
    )
    if user is None or membership is None or organization is None:
        raise _unauthorized()

    role_rows = await session.execute(
        select(Role.slug)
        .join(MembershipRole, MembershipRole.role_id == Role.id)
        .where(
            MembershipRole.organization_id == organization_id,
            MembershipRole.membership_id == membership.id,
        )
    )
    roles = tuple(sorted(set(role_rows.scalars().all())))

    permission_rows = await session.execute(
        select(Permission.key)
        .join(RolePermission, RolePermission.permission_id == Permission.id)
        .join(MembershipRole, MembershipRole.role_id == RolePermission.role_id)
        .where(
            MembershipRole.organization_id == organization_id,
            MembershipRole.membership_id == membership.id,
            RolePermission.organization_id == organization_id,
        )
    )
    permissions = frozenset(permission_rows.scalars().all())

    branch_rows = await session.execute(
        select(MembershipBranchScope.branch_id).where(
            MembershipBranchScope.organization_id == organization_id,
            MembershipBranchScope.membership_id == membership.id,
        )
    )
    branch_ids = frozenset(branch_rows.scalars().all())
    return UserContext(
        user=user,
        organization=organization,
        membership=membership,
        roles=roles,
        permissions=permissions,
        branch_ids=branch_ids,
        family_id=family_id,
    )


def require_permission(permission: str):
    async def dependency(context: UserContext = Depends(get_current_user_context)) -> UserContext:
        if permission not in context.permissions:
            raise HTTPException(status_code=403, detail=f"Missing permission: {permission}")
        return context

    return dependency


def branch_filter(query, context: UserContext):
    """Apply branch scope to a Branch select; empty branch scope means no branch access."""
    if context.organization_wide:
        return query
    if not context.branch_ids:
        return query.where(Branch.id.is_(None))
    return query.where(Branch.id.in_(context.branch_ids))
