# Migration reconciliation record

Date: 2026-11-09

## Current executable chain

| Revision | Purpose | Status |
|---|---|---|
| `001_core_identity` | Organizations, directory locator, users, branches, memberships and tenant RLS | Created in this build |
| `002_access_control` | Permission catalog, roles, role permissions, membership roles and tenant RLS | Created in this build |
| `003_organization_lifecycle` | Departments, branch scopes, invitations, invitation scopes, audit logs and tenant RLS | Created in this build |
| `004_auth_sessions` | Tenant-bound refresh-token families, rotation/reuse columns and RLS | Created in this build; supersedes supplied 012 table shape |
| `005_analytics_and_bi` | Initial tenant-scoped analytics dashboards and report-run persistence | Created in this build to satisfy downstream 006 dependency |

The migration chain currently has one Alembic head: `005_analytics_and_bi`. Offline SQL generation completes successfully. No live PostgreSQL upgrade has been run in this environment.

## Supplied migrations requiring further reconciliation

- Migration 006 and later migrations 007–011 are retained in the reference documents, not yet copied into the executable chain. Their table definitions, dependencies, policies, triggers and service assumptions must be compared with this base schema before porting.
- Supplied migration 012 attempts to create a refresh-token table. That table is not to be created a second time: revision 004 already creates a tenant-scoped table with token hash, family id, used/revoked state, replacement link, expiry and composite tenant/user constraints. Any useful 012 additions must be merged as an ALTER migration only after schema comparison.
- Source revisions include restrictive RLS policies. PostgreSQL restrictive policies are ANDed with permissive policies; each table must retain an intentional permissive tenant policy or all access may be denied. Current base policies are explicitly permissive.
- The source documents contain different revisions of crypto, pool reset, inventory and AI-gateway code. Do not copy them into this chain solely by filename order; compare callers and tests first.

## Invariants to preserve

1. Tenant context is transaction-local and must be rebound on every new transaction.
2. Tenant-scoped foreign keys include organization identity where a cross-tenant relationship could otherwise be represented.
3. Public organization lookup exposes only slug, display name and status; subscription/AI quota fields remain behind organization RLS.
4. Global user rows are protected by RLS: the current account can read its own row, and other users' profile rows are visible only inside a tenant where they hold membership. The internal email locator contains no password/profile data; direct table access is revoked from the runtime role, which can only call a function returning the ID for an exact email match.
5. Runtime API connections must use a dedicated non-superuser role without `BYPASSRLS`; migrations use a separate non-superuser schema-owner role, and bootstrap administrator credentials must not remain in the long-running API process.
6. Refresh tokens are stored as hashes, rotate once, and revoke their family on reuse.
7. Every new tenant table needs RLS, a permissive tenant policy, indexes, foreign-key review and isolation tests.
8. Downgrades must remove policies/triggers before tables and must be tested against a disposable PostgreSQL database before production use.
9. At most one pending invitation may exist for an organization/email pair; PostgreSQL enforces this with a partial unique index so concurrent invite requests cannot bypass the rule.
10. Runtime API credentials may append audit events but cannot update or delete existing audit rows; privileged retention/export jobs must use separately controlled credentials.
