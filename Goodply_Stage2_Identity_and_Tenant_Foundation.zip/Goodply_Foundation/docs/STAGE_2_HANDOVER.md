# Goodply — Stage 2 handover

Date: 2026-11-09

## Delivered in this stage

Stage 2 establishes the first secure organization/account foundation on top of the Stage 1 repository.

### Identity and organization lifecycle

- Register a first user and create an organization with a Head Office branch.
- Create and authenticate user accounts with Argon2 password hashes.
- Support one user identity belonging to multiple organizations through tenant membership records.
- Invite new or existing accounts into an organization, with organization- or branch-scoped invitations and one-time hashed invitation tokens.
- List and create branches, list organization members, create/update custom roles and assign roles to memberships.
- Seed organization roles for owner, administrator, general manager, branch manager, department manager, supervisor, support agent, sales representative, employee and auditor.

### Security and persistence controls

- Short-lived signed access cookies with issuer, audience and token-purpose checks.
- Opaque refresh tokens stored as hashes, single-use rotation, replacement links and family revocation on reuse.
- Double-submit CSRF protection for cookie-authenticated write requests.
- Redis-backed login and registration rate-limit checks (requires live Redis).
- Tenant/user transaction context is rebound on each transaction.
- Tenant tables use PostgreSQL RLS with explicit permissive tenant policies.
- Separate PostgreSQL bootstrap, non-superuser schema-migrator and non-superuser runtime roles. The API startup checks that the runtime role is the expected `goodply_app`-style role and is neither superuser nor `BYPASSRLS`.
- Runtime grants keep global locator/catalog tables read-only, deny direct access to the email identity directory, expose only an exact-email ID lookup function, make audit logs append-only and deny access to Alembic migration metadata.
- One pending invitation per organization/email is enforced by a partial unique index to close concurrent-invite races.

### Frontend in this stage

- Landing page, account registration, sign-in, authenticated workspace and system status screens.
- Shared fetch client with cookies, CSRF header handling and normalized API errors.

## Verification completed here

- Python compilation passed.
- 26 backend unit/API-contract tests passed.
- FastAPI imports and OpenAPI schema generation passed: 21 routes registered and 15 paths documented.
- 18 ORM tables registered.
- Alembic offline SQL preview generated for a single 001–005 migration chain (588 lines).
- PostgreSQL initialization shell syntax and Compose YAML structure checks passed.

## Not yet verified / not included

- No live PostgreSQL container/database was available, so migrations, RLS policies, cross-tenant isolation, role grants, foreign keys and concurrent requests have not been exercised against PostgreSQL.
- No live Redis integration test was run.
- Frontend dependencies could not be installed within this environment; TypeScript type-check and Next.js production build are not verified.
- Docker image builds, end-to-end browser tests, penetration tests, load tests, backup/restore and production deployment have not been performed.
- Email delivery, email verification, password reset, MFA/passkeys, membership switching, full branch/department scope administration, support operations and the 15 business modules are not part of this completed stage.

## Acceptance status

**Stage 2 code is prepared and locally unit-tested; it is not production-approved.** Before public or customer use, run the documented integration gates in `VERIFICATION_LOG.md` and complete the remaining security/account-lifecycle work.

## Next planned stage

Stage 3 builds the shared product shell: role-aware responsive navigation, organization/branch switching, user/profile/settings screens, notifications, global search, audit viewer, complete department/team and membership administration, and in-app bug reporting with request correlation IDs.
