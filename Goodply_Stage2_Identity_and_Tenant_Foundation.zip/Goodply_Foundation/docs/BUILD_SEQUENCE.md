# Goodply staged build and acceptance plan

Framework note: the supplied frontend snippets reference Next.js 14.2.3 / React 18. This fresh build uses Next.js 16.4.5 / React 19. Exact frontend dependencies still need a committed package lockfile and a successful production build before the frontend foundation can be accepted.

## Stage 1 — Repository and service foundation

Implemented:
- Repository structure for Next.js and FastAPI.
- Environment-based configuration and Docker Compose definitions for PostgreSQL, Redis, API and web.
- Health/liveness and dependency-readiness endpoints.
- Base frontend shell, API client and status page.
- Preservation and deduplication of the supplied source material.

## Stage 2 — Identity and tenant foundation

Implemented in source and locally unit-tested:
- Single Alembic base chain 001–005: organizations, global user identity, branches, memberships, permission catalog, organization roles, invitations, branch scopes, audit records, refresh-token families and initial analytics/report scaffolding.
- Organization registration, login, logout, current identity, invitation acceptance and refresh-token rotation/reuse detection.
- HTTP-only access/refresh cookies, CSRF double-submit middleware, Argon2 password hashing and Redis-backed login/registration rate limits.
- Tenant transaction context reapplication and PostgreSQL RLS policies on tenant tables.
- Configurable organization role/permission management, organization/branch scoping and protection against removing the last active owner.
- Frontend registration, login and authenticated workspace views.

Not yet accepted as production-ready: live PostgreSQL/RLS validation, Redis rate-limit integration, refresh concurrency/reuse integration tests, frontend production build, email delivery, MFA, password reset, email verification and full membership-scope management.

## Stage 3 — Shared application shell

- Responsive navigation and role-aware module access.
- Organization and branch switcher, profile/settings, notifications, global search and a usable audit-event viewer.
- Department/team administration and complete membership lifecycle.
- Frontend error boundary, in-app bug reporting and request correlation IDs.

## Stage 4 — Business modules

Build each of the 15 modules behind shared identity, tenant, permission, audit and event infrastructure. Each module needs schema, service, API, UI, branch/department authorization, tests, and documented external dependencies before it is marked implemented.

## Stage 5 — AI, automation and integrations

- Real provider clients, tenant-aware AI configuration, idempotent quota reservation/settlement and recovery.
- Knowledge retrieval with permission-aware source citations.
- Workflow execution engine, retry/dead-letter behavior and approvals.
- OAuth/API integrations, encrypted credential storage, signed webhooks and provider-specific tests.

## Stage 6 — Global operations and SaaS administration

- Platform admin separated from tenant admins.
- Support/incident management, subscription ledger, entitlements, monitoring, audit, backup/restore and release controls.

## Stage 7 — Mobile and release engineering

- Reconcile shared frontend components and choose a maintainable mobile approach.
- Android/iOS app builds, end-to-end tests, signing, store metadata, deployment runbooks and user handover.

## Verification policy

Every stage records commands, exact outcomes, failed/skipped checks and external dependencies. Static compilation is not runtime integration testing; mocked tests are not live-provider tests; offline migration SQL generation is not a live database migration; local unit tests are not production security certification.
