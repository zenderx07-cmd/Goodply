BEGIN;

CREATE TABLE alembic_version (
    version_num VARCHAR(32) NOT NULL, 
    CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num)
);

-- Running upgrade  -> 001_core_identity

REVOKE CREATE ON SCHEMA public FROM PUBLIC;

CREATE TABLE organizations (
    id UUID DEFAULT gen_random_uuid() NOT NULL, 
    name VARCHAR(200) NOT NULL, 
    slug VARCHAR(63) NOT NULL, 
    status VARCHAR(20) DEFAULT 'active' NOT NULL, 
    tier VARCHAR(30) DEFAULT 'starter' NOT NULL, 
    ai_token_allowance_monthly INTEGER DEFAULT '100000' NOT NULL, 
    ai_tokens_consumed_current_cycle INTEGER DEFAULT '0' NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL, 
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL, 
    CONSTRAINT pk_organizations PRIMARY KEY (id), 
    CONSTRAINT uq_organizations_slug UNIQUE (slug), 
    CONSTRAINT ck_organizations_ck_organizations_status CHECK (status IN ('active','trial','suspended','closed')), 
    CONSTRAINT ck_organizations_ck_organizations_tier CHECK (tier IN ('starter','professional','business','enterprise')), 
    CONSTRAINT ck_organizations_ck_organizations_ai_usage_nonnegative CHECK (ai_token_allowance_monthly >= 0 AND ai_tokens_consumed_current_cycle >= 0)
);

CREATE TABLE organization_directory (
    organization_id UUID NOT NULL, 
    slug VARCHAR(63) NOT NULL, 
    display_name VARCHAR(200) NOT NULL, 
    status VARCHAR(20) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL, 
    CONSTRAINT pk_organization_directory PRIMARY KEY (organization_id), 
    CONSTRAINT uq_organization_directory_slug UNIQUE (slug)
);

CREATE OR REPLACE FUNCTION sync_organization_directory()
        RETURNS TRIGGER
        LANGUAGE plpgsql
        SECURITY DEFINER
        SET search_path = pg_catalog, public, pg_temp
        AS $$
        BEGIN
            IF TG_OP = 'DELETE' THEN
                DELETE FROM public.organization_directory WHERE organization_id = OLD.id;
                RETURN OLD;
            END IF;
            INSERT INTO public.organization_directory (organization_id, slug, display_name, status)
            VALUES (NEW.id, NEW.slug, NEW.name, NEW.status)
            ON CONFLICT (organization_id) DO UPDATE SET
                slug = EXCLUDED.slug,
                display_name = EXCLUDED.display_name,
                status = EXCLUDED.status;
            RETURN NEW;
        END;
        $$;;

CREATE TRIGGER trg_sync_organization_directory
        AFTER INSERT OR UPDATE OR DELETE ON organizations
        FOR EACH ROW EXECUTE FUNCTION sync_organization_directory();

ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;

ALTER TABLE organizations FORCE ROW LEVEL SECURITY;

CREATE POLICY organizations_tenant_access ON organizations
        AS PERMISSIVE FOR ALL
        USING (id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid)
        WITH CHECK (id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid);

CREATE TABLE users (
    id UUID DEFAULT gen_random_uuid() NOT NULL, 
    email VARCHAR(320) NOT NULL, 
    email_normalized VARCHAR(320) NOT NULL, 
    password_hash VARCHAR(512) NOT NULL, 
    full_name VARCHAR(120) NOT NULL, 
    is_active BOOLEAN DEFAULT true NOT NULL, 
    email_verified_at TIMESTAMP WITH TIME ZONE, 
    last_login_at TIMESTAMP WITH TIME ZONE, 
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL, 
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL, 
    CONSTRAINT pk_users PRIMARY KEY (id), 
    CONSTRAINT uq_users_email_normalized UNIQUE (email_normalized), 
    CONSTRAINT ck_users_ck_users_email_normalized CHECK (email_normalized = lower(trim(email_normalized)))
);

CREATE TABLE user_identity_directory (
    user_id UUID NOT NULL, 
    email_normalized VARCHAR(320) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL, 
    CONSTRAINT pk_user_identity_directory PRIMARY KEY (user_id), 
    CONSTRAINT fk_user_identity_directory_user_id_users FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE, 
    CONSTRAINT uq_user_identity_directory_email_normalized UNIQUE (email_normalized)
);

CREATE OR REPLACE FUNCTION sync_user_identity_directory()
        RETURNS TRIGGER
        LANGUAGE plpgsql
        SECURITY DEFINER
        SET search_path = pg_catalog, public, pg_temp
        AS $$
        BEGIN
            IF TG_OP = 'DELETE' THEN
                DELETE FROM public.user_identity_directory WHERE user_id = OLD.id;
                RETURN OLD;
            END IF;
            INSERT INTO public.user_identity_directory (user_id, email_normalized)
            VALUES (NEW.id, NEW.email_normalized)
            ON CONFLICT (user_id) DO UPDATE SET
                email_normalized = EXCLUDED.email_normalized;
            RETURN NEW;
        END;
        $$;;

CREATE TRIGGER trg_sync_user_identity_directory
        AFTER INSERT OR UPDATE OF email_normalized OR DELETE ON users
        FOR EACH ROW EXECUTE FUNCTION sync_user_identity_directory();

CREATE OR REPLACE FUNCTION lookup_user_id_by_email(p_email TEXT)
        RETURNS UUID
        LANGUAGE SQL
        STABLE
        SECURITY DEFINER
        SET search_path = pg_catalog, public
        AS $$
            SELECT user_id
            FROM public.user_identity_directory
            WHERE email_normalized = lower(btrim(p_email))
            LIMIT 1
        $$;

REVOKE ALL ON FUNCTION lookup_user_id_by_email(TEXT) FROM PUBLIC;

CREATE TABLE branches (
    id UUID DEFAULT gen_random_uuid() NOT NULL, 
    organization_id UUID NOT NULL, 
    name VARCHAR(150) NOT NULL, 
    code VARCHAR(30) NOT NULL, 
    address VARCHAR(500), 
    city VARCHAR(120), 
    country_code VARCHAR(2), 
    timezone VARCHAR(64) DEFAULT 'UTC' NOT NULL, 
    phone VARCHAR(40), 
    is_active BOOLEAN DEFAULT true NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL, 
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL, 
    CONSTRAINT pk_branches PRIMARY KEY (id), 
    CONSTRAINT uq_branches_org_code UNIQUE (organization_id, code), 
    CONSTRAINT uq_branches_org_id UNIQUE (organization_id, id), 
    CONSTRAINT fk_branches_organization_id_organizations FOREIGN KEY(organization_id) REFERENCES organizations (id) ON DELETE CASCADE
);

CREATE INDEX ix_branches_org_active ON branches (organization_id, is_active);

CREATE TABLE organization_memberships (
    id UUID DEFAULT gen_random_uuid() NOT NULL, 
    organization_id UUID NOT NULL, 
    user_id UUID NOT NULL, 
    status VARCHAR(20) DEFAULT 'active' NOT NULL, 
    scope_level VARCHAR(20) DEFAULT 'branches' NOT NULL, 
    job_title VARCHAR(120), 
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL, 
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL, 
    CONSTRAINT pk_organization_memberships PRIMARY KEY (id), 
    CONSTRAINT uq_membership_org_user UNIQUE (organization_id, user_id), 
    CONSTRAINT uq_membership_org_id UNIQUE (organization_id, id), 
    CONSTRAINT ck_organization_memberships_ck_membership_status CHECK (status IN ('active','invited','suspended','left')), 
    CONSTRAINT ck_organization_memberships_ck_membership_scope_level CHECK (scope_level IN ('organization','branches','department')), 
    CONSTRAINT fk_organization_memberships_organization_id_organizations FOREIGN KEY(organization_id) REFERENCES organizations (id) ON DELETE CASCADE, 
    CONSTRAINT fk_organization_memberships_user_id_users FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE
);

CREATE INDEX ix_memberships_user_status ON organization_memberships (user_id, status);

ALTER TABLE branches ENABLE ROW LEVEL SECURITY;

ALTER TABLE branches FORCE ROW LEVEL SECURITY;

CREATE POLICY branches_tenant_access ON branches
        AS PERMISSIVE FOR ALL
        USING (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid)
        WITH CHECK (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid);

ALTER TABLE organization_memberships ENABLE ROW LEVEL SECURITY;

ALTER TABLE organization_memberships FORCE ROW LEVEL SECURITY;

CREATE POLICY organization_memberships_tenant_access ON organization_memberships
        AS PERMISSIVE FOR ALL
        USING (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid)
        WITH CHECK (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid);

ALTER TABLE users ENABLE ROW LEVEL SECURITY;

ALTER TABLE users FORCE ROW LEVEL SECURITY;

CREATE POLICY users_tenant_or_self_access ON users
        AS PERMISSIVE FOR ALL
        USING (
            id = NULLIF(current_setting('app.current_user_id', true), '')::uuid
            OR EXISTS (
                SELECT 1 FROM organization_memberships m
                WHERE m.user_id = users.id
                  AND m.organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid
            )
        )
        WITH CHECK (
            id = NULLIF(current_setting('app.current_user_id', true), '')::uuid
            OR EXISTS (
                SELECT 1 FROM organization_memberships m
                WHERE m.user_id = users.id
                  AND m.organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid
            )
        );

INSERT INTO alembic_version (version_num) VALUES ('001_core_identity') RETURNING alembic_version.version_num;

-- Running upgrade 001_core_identity -> 002_access_control

CREATE TABLE permissions (
    id UUID DEFAULT gen_random_uuid() NOT NULL, 
    key VARCHAR(100) NOT NULL, 
    module VARCHAR(50) NOT NULL, 
    description VARCHAR(255) NOT NULL, 
    CONSTRAINT pk_permissions PRIMARY KEY (id), 
    CONSTRAINT uq_permissions_key UNIQUE (key)
);

INSERT INTO permissions (key, module, description) VALUES ('organization:read', 'organization', 'View organization profile');

INSERT INTO permissions (key, module, description) VALUES ('organization:update', 'organization', 'Update organization profile');

INSERT INTO permissions (key, module, description) VALUES ('organization:delete', 'organization', 'Delete organization');

INSERT INTO permissions (key, module, description) VALUES ('branches:read', 'branches', 'View branches');

INSERT INTO permissions (key, module, description) VALUES ('branches:manage', 'branches', 'Create and manage branches');

INSERT INTO permissions (key, module, description) VALUES ('members:read', 'members', 'View organization members');

INSERT INTO permissions (key, module, description) VALUES ('members:invite', 'members', 'Invite organization members');

INSERT INTO permissions (key, module, description) VALUES ('members:manage', 'members', 'Manage organization members');

INSERT INTO permissions (key, module, description) VALUES ('roles:read', 'access_control', 'View roles and permissions');

INSERT INTO permissions (key, module, description) VALUES ('roles:manage', 'access_control', 'Manage roles and permissions');

INSERT INTO permissions (key, module, description) VALUES ('departments:read', 'workforce', 'View departments');

INSERT INTO permissions (key, module, description) VALUES ('departments:manage', 'workforce', 'Manage departments');

INSERT INTO permissions (key, module, description) VALUES ('audit:read', 'security', 'View audit events');

INSERT INTO permissions (key, module, description) VALUES ('analytics:read', 'analytics', 'View analytics and reports');

INSERT INTO permissions (key, module, description) VALUES ('analytics:manage', 'analytics', 'Manage dashboards and reports');

INSERT INTO permissions (key, module, description) VALUES ('reviews:read', 'reputation', 'View reviews');

INSERT INTO permissions (key, module, description) VALUES ('reviews:respond', 'reputation', 'Respond to reviews');

INSERT INTO permissions (key, module, description) VALUES ('crm:read', 'crm', 'View CRM records');

INSERT INTO permissions (key, module, description) VALUES ('crm:write', 'crm', 'Create and update CRM records');

INSERT INTO permissions (key, module, description) VALUES ('inbox:read', 'inbox', 'View conversations');

INSERT INTO permissions (key, module, description) VALUES ('inbox:reply', 'inbox', 'Reply to conversations');

INSERT INTO permissions (key, module, description) VALUES ('tickets:read', 'helpdesk', 'View support tickets');

INSERT INTO permissions (key, module, description) VALUES ('tickets:manage', 'helpdesk', 'Manage support tickets');

INSERT INTO permissions (key, module, description) VALUES ('tasks:read', 'operations', 'View tasks');

INSERT INTO permissions (key, module, description) VALUES ('tasks:manage', 'operations', 'Manage tasks');

INSERT INTO permissions (key, module, description) VALUES ('sales:read', 'sales', 'View sales pipeline');

INSERT INTO permissions (key, module, description) VALUES ('sales:manage', 'sales', 'Manage sales pipeline');

INSERT INTO permissions (key, module, description) VALUES ('marketing:read', 'marketing', 'View marketing campaigns');

INSERT INTO permissions (key, module, description) VALUES ('marketing:manage', 'marketing', 'Manage marketing campaigns');

INSERT INTO permissions (key, module, description) VALUES ('inventory:read', 'inventory', 'View inventory');

INSERT INTO permissions (key, module, description) VALUES ('inventory:write', 'inventory', 'Manage inventory');

INSERT INTO permissions (key, module, description) VALUES ('workforce:read', 'workforce', 'View workforce records');

INSERT INTO permissions (key, module, description) VALUES ('workforce:manage', 'workforce', 'Manage workforce records');

INSERT INTO permissions (key, module, description) VALUES ('integrations:read', 'integrations', 'View integrations');

INSERT INTO permissions (key, module, description) VALUES ('integrations:manage', 'integrations', 'Manage integrations');

INSERT INTO permissions (key, module, description) VALUES ('settings:manage', 'settings', 'Manage organization settings');

CREATE TABLE roles (
    id UUID DEFAULT gen_random_uuid() NOT NULL, 
    organization_id UUID NOT NULL, 
    name VARCHAR(100) NOT NULL, 
    slug VARCHAR(80) NOT NULL, 
    description VARCHAR(255), 
    is_system BOOLEAN DEFAULT false NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL, 
    CONSTRAINT pk_roles PRIMARY KEY (id), 
    CONSTRAINT uq_roles_org_slug UNIQUE (organization_id, slug), 
    CONSTRAINT uq_roles_org_id UNIQUE (organization_id, id), 
    CONSTRAINT fk_roles_organization_id_organizations FOREIGN KEY(organization_id) REFERENCES organizations (id) ON DELETE CASCADE
);

CREATE TABLE role_permissions (
    id UUID DEFAULT gen_random_uuid() NOT NULL, 
    organization_id UUID NOT NULL, 
    role_id UUID NOT NULL, 
    permission_id UUID NOT NULL, 
    CONSTRAINT pk_role_permissions PRIMARY KEY (id), 
    CONSTRAINT fk_role_permissions_organization_id_roles FOREIGN KEY(organization_id, role_id) REFERENCES roles (organization_id, id) ON DELETE CASCADE, 
    CONSTRAINT uq_role_permission UNIQUE (organization_id, role_id, permission_id), 
    CONSTRAINT fk_role_permissions_permission_id_permissions FOREIGN KEY(permission_id) REFERENCES permissions (id) ON DELETE CASCADE
);

CREATE TABLE membership_roles (
    id UUID DEFAULT gen_random_uuid() NOT NULL, 
    organization_id UUID NOT NULL, 
    membership_id UUID NOT NULL, 
    role_id UUID NOT NULL, 
    CONSTRAINT pk_membership_roles PRIMARY KEY (id), 
    CONSTRAINT fk_membership_roles_organization_id_organization_memberships FOREIGN KEY(organization_id, membership_id) REFERENCES organization_memberships (organization_id, id) ON DELETE CASCADE, 
    CONSTRAINT fk_membership_roles_organization_id_roles FOREIGN KEY(organization_id, role_id) REFERENCES roles (organization_id, id) ON DELETE CASCADE, 
    CONSTRAINT uq_membership_role UNIQUE (organization_id, membership_id, role_id)
);

ALTER TABLE roles ENABLE ROW LEVEL SECURITY;

ALTER TABLE roles FORCE ROW LEVEL SECURITY;

CREATE POLICY roles_tenant_access ON roles
        AS PERMISSIVE FOR ALL
        USING (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid)
        WITH CHECK (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid);

ALTER TABLE role_permissions ENABLE ROW LEVEL SECURITY;

ALTER TABLE role_permissions FORCE ROW LEVEL SECURITY;

CREATE POLICY role_permissions_tenant_access ON role_permissions
        AS PERMISSIVE FOR ALL
        USING (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid)
        WITH CHECK (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid);

ALTER TABLE membership_roles ENABLE ROW LEVEL SECURITY;

ALTER TABLE membership_roles FORCE ROW LEVEL SECURITY;

CREATE POLICY membership_roles_tenant_access ON membership_roles
        AS PERMISSIVE FOR ALL
        USING (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid)
        WITH CHECK (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid);

UPDATE alembic_version SET version_num='002_access_control' WHERE alembic_version.version_num = '001_core_identity';

-- Running upgrade 002_access_control -> 003_organization_lifecycle

CREATE TABLE departments (
    id UUID DEFAULT gen_random_uuid() NOT NULL, 
    organization_id UUID NOT NULL, 
    name VARCHAR(100) NOT NULL, 
    description VARCHAR(255), 
    is_active BOOLEAN DEFAULT true NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL, 
    CONSTRAINT pk_departments PRIMARY KEY (id), 
    CONSTRAINT uq_departments_org_name UNIQUE (organization_id, name), 
    CONSTRAINT uq_departments_org_id UNIQUE (organization_id, id), 
    CONSTRAINT fk_departments_organization_id_organizations FOREIGN KEY(organization_id) REFERENCES organizations (id) ON DELETE CASCADE
);

CREATE TABLE membership_branch_scopes (
    id UUID DEFAULT gen_random_uuid() NOT NULL, 
    organization_id UUID NOT NULL, 
    membership_id UUID NOT NULL, 
    branch_id UUID NOT NULL, 
    CONSTRAINT pk_membership_branch_scopes PRIMARY KEY (id), 
    CONSTRAINT fk_membership_branch_scopes_organization_id_organizatio_df37 FOREIGN KEY(organization_id, membership_id) REFERENCES organization_memberships (organization_id, id) ON DELETE CASCADE, 
    CONSTRAINT fk_membership_branch_scopes_organization_id_branches FOREIGN KEY(organization_id, branch_id) REFERENCES branches (organization_id, id) ON DELETE CASCADE, 
    CONSTRAINT uq_membership_branch_scope UNIQUE (organization_id, membership_id, branch_id)
);

CREATE TABLE organization_invitations (
    id UUID DEFAULT gen_random_uuid() NOT NULL, 
    organization_id UUID NOT NULL, 
    email_normalized VARCHAR(320) NOT NULL, 
    token_hash VARCHAR(64) NOT NULL, 
    role_id UUID NOT NULL, 
    invited_by_user_id UUID NOT NULL, 
    status VARCHAR(20) DEFAULT 'pending' NOT NULL, 
    scope_level VARCHAR(20) DEFAULT 'branches' NOT NULL, 
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    accepted_at TIMESTAMP WITH TIME ZONE, 
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL, 
    CONSTRAINT pk_organization_invitations PRIMARY KEY (id), 
    CONSTRAINT fk_organization_invitations_organization_id_roles FOREIGN KEY(organization_id, role_id) REFERENCES roles (organization_id, id) ON DELETE CASCADE, 
    CONSTRAINT uq_invitations_org_id UNIQUE (organization_id, id), 
    CONSTRAINT ck_organization_invitations_ck_invitation_status CHECK (status IN ('pending','accepted','expired','revoked')), 
    CONSTRAINT ck_organization_invitations_ck_invitation_scope_level CHECK (scope_level IN ('organization','branches')), 
    CONSTRAINT fk_organization_invitations_organization_id_organizations FOREIGN KEY(organization_id) REFERENCES organizations (id) ON DELETE CASCADE, 
    CONSTRAINT uq_organization_invitations_token_hash UNIQUE (token_hash), 
    CONSTRAINT fk_organization_invitations_invited_by_user_id_users FOREIGN KEY(invited_by_user_id) REFERENCES users (id) ON DELETE RESTRICT
);

CREATE INDEX ix_invitations_org_status ON organization_invitations (organization_id, status);

CREATE UNIQUE INDEX uq_invitations_org_email_pending ON organization_invitations (organization_id, email_normalized) WHERE status = 'pending';

CREATE TABLE invitation_branch_scopes (
    id UUID DEFAULT gen_random_uuid() NOT NULL, 
    organization_id UUID NOT NULL, 
    invitation_id UUID NOT NULL, 
    branch_id UUID NOT NULL, 
    CONSTRAINT pk_invitation_branch_scopes PRIMARY KEY (id), 
    CONSTRAINT fk_invitation_branch_scopes_organization_id_organizatio_65a3 FOREIGN KEY(organization_id, invitation_id) REFERENCES organization_invitations (organization_id, id) ON DELETE CASCADE, 
    CONSTRAINT fk_invitation_branch_scopes_organization_id_branches FOREIGN KEY(organization_id, branch_id) REFERENCES branches (organization_id, id) ON DELETE CASCADE, 
    CONSTRAINT uq_invitation_branch_scope UNIQUE (organization_id, invitation_id, branch_id)
);

CREATE TABLE audit_logs (
    id UUID DEFAULT gen_random_uuid() NOT NULL, 
    organization_id UUID NOT NULL, 
    actor_user_id UUID, 
    action VARCHAR(100) NOT NULL, 
    entity_type VARCHAR(80) NOT NULL, 
    entity_id VARCHAR(80), 
    metadata JSONB DEFAULT '{}'::jsonb NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL, 
    CONSTRAINT pk_audit_logs PRIMARY KEY (id), 
    CONSTRAINT fk_audit_logs_organization_id_organizations FOREIGN KEY(organization_id) REFERENCES organizations (id) ON DELETE CASCADE, 
    CONSTRAINT fk_audit_logs_actor_user_id_users FOREIGN KEY(actor_user_id) REFERENCES users (id) ON DELETE SET NULL
);

CREATE INDEX ix_audit_logs_org_created ON audit_logs (organization_id, created_at);

ALTER TABLE departments ENABLE ROW LEVEL SECURITY;

ALTER TABLE departments FORCE ROW LEVEL SECURITY;

CREATE POLICY departments_tenant_access ON departments
        AS PERMISSIVE FOR ALL
        USING (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid)
        WITH CHECK (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid);

ALTER TABLE membership_branch_scopes ENABLE ROW LEVEL SECURITY;

ALTER TABLE membership_branch_scopes FORCE ROW LEVEL SECURITY;

CREATE POLICY membership_branch_scopes_tenant_access ON membership_branch_scopes
        AS PERMISSIVE FOR ALL
        USING (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid)
        WITH CHECK (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid);

ALTER TABLE organization_invitations ENABLE ROW LEVEL SECURITY;

ALTER TABLE organization_invitations FORCE ROW LEVEL SECURITY;

CREATE POLICY organization_invitations_tenant_access ON organization_invitations
        AS PERMISSIVE FOR ALL
        USING (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid)
        WITH CHECK (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid);

ALTER TABLE invitation_branch_scopes ENABLE ROW LEVEL SECURITY;

ALTER TABLE invitation_branch_scopes FORCE ROW LEVEL SECURITY;

CREATE POLICY invitation_branch_scopes_tenant_access ON invitation_branch_scopes
        AS PERMISSIVE FOR ALL
        USING (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid)
        WITH CHECK (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid);

ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

ALTER TABLE audit_logs FORCE ROW LEVEL SECURITY;

CREATE POLICY audit_logs_tenant_access ON audit_logs
        AS PERMISSIVE FOR ALL
        USING (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid)
        WITH CHECK (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid);

UPDATE alembic_version SET version_num='003_organization_lifecycle' WHERE alembic_version.version_num = '002_access_control';

-- Running upgrade 003_organization_lifecycle -> 004_auth_sessions

CREATE TABLE auth_refresh_tokens (
    id UUID DEFAULT gen_random_uuid() NOT NULL, 
    organization_id UUID NOT NULL, 
    user_id UUID NOT NULL, 
    token_hash VARCHAR(64) NOT NULL, 
    family_id UUID NOT NULL, 
    is_revoked BOOLEAN DEFAULT false NOT NULL, 
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL, 
    used_at TIMESTAMP WITH TIME ZONE, 
    replaced_by_token_id UUID, 
    revoked_at TIMESTAMP WITH TIME ZONE, 
    revocation_reason VARCHAR(80), 
    CONSTRAINT pk_auth_refresh_tokens PRIMARY KEY (id), 
    CONSTRAINT fk_auth_refresh_tokens_organization_id_organization_memberships FOREIGN KEY(organization_id, user_id) REFERENCES organization_memberships (organization_id, user_id) ON DELETE CASCADE, 
    CONSTRAINT fk_auth_refresh_tokens_organization_id_auth_refresh_tokens FOREIGN KEY(organization_id, replaced_by_token_id) REFERENCES auth_refresh_tokens (organization_id, id), 
    CONSTRAINT uq_refresh_tokens_org_id UNIQUE (organization_id, id), 
    CONSTRAINT uq_auth_refresh_tokens_token_hash UNIQUE (token_hash)
);

CREATE INDEX ix_refresh_tokens_family ON auth_refresh_tokens (organization_id, family_id);

CREATE INDEX ix_refresh_tokens_user_expiry ON auth_refresh_tokens (organization_id, user_id, expires_at);

ALTER TABLE auth_refresh_tokens ENABLE ROW LEVEL SECURITY;

ALTER TABLE auth_refresh_tokens FORCE ROW LEVEL SECURITY;

CREATE POLICY auth_refresh_tokens_tenant_access ON auth_refresh_tokens
        AS PERMISSIVE FOR ALL
        USING (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid)
        WITH CHECK (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid);

UPDATE alembic_version SET version_num='004_auth_sessions' WHERE alembic_version.version_num = '003_organization_lifecycle';

-- Running upgrade 004_auth_sessions -> 005_analytics_and_bi

CREATE TABLE analytics_dashboards (
    id UUID DEFAULT gen_random_uuid() NOT NULL, 
    organization_id UUID NOT NULL, 
    owner_user_id UUID NOT NULL, 
    title VARCHAR(160) NOT NULL, 
    visibility VARCHAR(20) DEFAULT 'private' NOT NULL, 
    configuration JSONB DEFAULT '{}'::jsonb NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL, 
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL, 
    CONSTRAINT pk_analytics_dashboards PRIMARY KEY (id), 
    CONSTRAINT ck_analytics_dashboards_ck_analytics_dashboard_visibility CHECK (visibility IN ('private','organization')), 
    CONSTRAINT fk_analytics_dashboards_organization_id_organizations FOREIGN KEY(organization_id) REFERENCES organizations (id) ON DELETE CASCADE, 
    CONSTRAINT fk_analytics_dashboards_owner_user_id_users FOREIGN KEY(owner_user_id) REFERENCES users (id) ON DELETE CASCADE
);

CREATE TABLE analytics_report_runs (
    id UUID DEFAULT gen_random_uuid() NOT NULL, 
    organization_id UUID NOT NULL, 
    requested_by_user_id UUID, 
    report_key VARCHAR(100) NOT NULL, 
    parameters JSONB DEFAULT '{}'::jsonb NOT NULL, 
    status VARCHAR(20) DEFAULT 'queued' NOT NULL, 
    result_object_key VARCHAR(500), 
    started_at TIMESTAMP WITH TIME ZONE, 
    completed_at TIMESTAMP WITH TIME ZONE, 
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL, 
    CONSTRAINT pk_analytics_report_runs PRIMARY KEY (id), 
    CONSTRAINT ck_analytics_report_runs_ck_analytics_report_run_status CHECK (status IN ('queued','running','completed','failed')), 
    CONSTRAINT fk_analytics_report_runs_organization_id_organizations FOREIGN KEY(organization_id) REFERENCES organizations (id) ON DELETE CASCADE, 
    CONSTRAINT fk_analytics_report_runs_requested_by_user_id_users FOREIGN KEY(requested_by_user_id) REFERENCES users (id) ON DELETE SET NULL
);

CREATE INDEX ix_analytics_report_runs_org_created ON analytics_report_runs (organization_id, created_at);

ALTER TABLE analytics_dashboards ENABLE ROW LEVEL SECURITY;

ALTER TABLE analytics_dashboards FORCE ROW LEVEL SECURITY;

CREATE POLICY analytics_dashboards_tenant_access ON analytics_dashboards
        AS PERMISSIVE FOR ALL
        USING (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid)
        WITH CHECK (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid);

ALTER TABLE analytics_report_runs ENABLE ROW LEVEL SECURITY;

ALTER TABLE analytics_report_runs FORCE ROW LEVEL SECURITY;

CREATE POLICY analytics_report_runs_tenant_access ON analytics_report_runs
        AS PERMISSIVE FOR ALL
        USING (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid)
        WITH CHECK (organization_id = NULLIF(current_setting('app.current_tenant_id', true), '')::uuid);

UPDATE alembic_version SET version_num='005_analytics_and_bi' WHERE alembic_version.version_num = '004_auth_sessions';

COMMIT;

