# Goodply verification log — Stage 2

Date: 2026-11-09

## Checks executed in the available environment

| Check | Result | Evidence / limitation |
|---|---|---|
| Python compilation | PASS | `python -m compileall -q app migrations tests` |
| Backend unit/API-contract tests | PASS | `pytest -q`: **26 passed** in 0.74 seconds, no warnings |
| FastAPI app import and OpenAPI generation | PASS | 21 routes registered; 15 OpenAPI paths generated |
| ORM metadata registration | PASS | 18 tables registered; pending-invitation partial unique index is declared in metadata |
| Alembic migration graph | PASS | `alembic heads` reports one head: `005_analytics_and_bi` |
| Offline migration SQL generation | PASS | `alembic upgrade head --sql` generated 588 lines through revision 005; preview saved as `migration_preview_001_005.sql` |
| Auth security unit tests | PASS | Argon2 hash/verify, JWT signature, issuer/audience and access-token type, opaque refresh-token hashing and malformed prefix |
| Schema/validation unit tests | PASS | Registration/login validation, branch timezone/country normalization, duplicate branch and role IDs, role slug normalization |
| Access-control policy unit tests | PASS | Ten built-in role templates, owner wildcard and read-only auditor policy |
| CSRF unit tests | PASS | Cookie-authenticated write without matching double-submit token is rejected |
| PostgreSQL init shell syntax | PASS | `sh -n database/init/01-create-app-role.sh` |
| Docker Compose YAML structure | PASS | Parsed YAML; postgres, redis, backend and frontend services found; public API URL is a frontend build argument |
| Live PostgreSQL migration / RLS / foreign-key / runtime-role tests | NOT RUN | No PostgreSQL service, Docker/Podman, `psql`, `asyncpg` driver or live DB endpoint in this build environment; application startup now checks the connected role when a DB URL is configured |
| Redis rate-limit integration | NOT RUN | No Redis service or Python Redis package in the build environment; dependency is declared for container installation |
| Frontend dependency install / type-check / production build | NOT RUN TO COMPLETION | `npm install` timed out; no successful type-check/build is claimed and no lockfile is available yet |
| Docker Compose build/start | NOT RUN | Docker/Podman unavailable in the build environment |
| End-to-end browser tests | NOT RUN | Frontend dependencies and live services unavailable |
| Penetration, load and disaster-recovery tests | NOT RUN | Require dedicated staging infrastructure and a test plan |

## Additional Stage 2 hardening

- The runtime database role is configured as `NOSUPERUSER` and `NOBYPASSRLS`; migrations use a separate non-superuser schema-owner role, while the bootstrap administrator is used only by PostgreSQL initialization. The migration connection is removed from the API process before Uvicorn starts. API startup checks the connected PostgreSQL role name and rejects superuser or `BYPASSRLS` connections.
- Direct reads from the user identity directory are revoked; the runtime role can execute only an exact-email lookup function that returns an account UUID.
- Audit log UPDATE/DELETE privileges and all privileges on the Alembic version table are revoked from the runtime API role; ordinary application writes are append-only.
- A PostgreSQL partial unique index permits only one `pending` invitation per organization/email pair, including concurrent request races.
- Access-token decoding now verifies the explicit `typ=access` claim as well as signature, issuer, audience and required claims.
- The frontend API base URL is supplied as a Docker build argument so a deployed browser bundle does not have to rely on a hard-coded localhost URL.

## Open acceptance items

- Provision the `goodply_app` role as a non-superuser, verify it has no `BYPASSRLS`, confirm locator/catalog tables are read-only and the email lookup function exposes only exact-match IDs, and confirm migration credentials are not exposed to the running API process.
- Run the 001–005 migration chain against PostgreSQL 16 and inspect the resulting schema, identity-directory triggers, RLS policies, partial unique index and composite constraints.
- Add database integration tests for tenant isolation, transaction-context restoration after commit, invite races, session rotation races and owner-lockout protection.
- Run Redis-backed rate-limit tests and test fail-closed behavior during Redis outages in staging.
- Install frontend dependencies in a network-enabled environment, commit a lockfile, run `npm run typecheck` and `npm run build`, then add browser-level auth flows.
- Review invitation delivery, email verification, MFA, recovery, password reset and account lifecycle before public launch.
- Continue reconciling source migrations 006–011 and provider/service code before adding more modules.

## Release status

Stage 2 source is implemented and passes local Python tests, static checks and offline migration generation. It is **not production-approved** because live database/RLS, Redis, frontend build, Docker deployment and end-to-end/security tests remain outstanding.
