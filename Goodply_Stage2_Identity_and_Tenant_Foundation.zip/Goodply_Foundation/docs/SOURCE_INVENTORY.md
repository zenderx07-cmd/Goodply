# Goodply source inventory

The build uses the six unique source documents below. The source documents specify Next.js 14.2.3 / React 18; this new scaffold deliberately upgrades to Next.js 16.4.5 / React 19 because Next.js 14 is now unsupported. See the official Next.js support policy and release record cited in the build notes. The duplicate `(1)` copies in the supplied material were byte-for-byte identical to their corresponding originals and are not copied again.

| Canonical reference | Main content identified |
|---|---|
| `MASTER_SPECIFICATION.txt` | Product requirements, 15 business/platform modules, roles, integrations, security and scale expectations |
| `AI_tool_phase6_frontend_backend.txt` | Phase 6 FastAPI modules, consolidated app imports, Next.js package/config, dashboard and module page implementations |
| `AI_tool_remediation_007.txt` | Initial remediation backlog, crypto, health, migration 007, inventory ledger, AI accounting, frontend API client and tests |
| `AI_tool_remediation_008.txt` | AES-GCM, database pool isolation, migration 008, inventory upsert, AI gateway, readiness and tests |
| `AI_tool_remediation_009.txt` | Tenant-bound keyring crypto, migration 009, AI reservations, CSRF/cookie auth, double-entry inventory and monitoring |
| `AI_tool_remediation_010_012.txt` | Migration 010 reservations, migration 011 double-entry enforcement, pool recovery, CSRF hardening, migration 012 refresh-token families and tests |

## Reconciliation rules

1. The newest document is not automatically correct; a later revision must be checked against earlier callers, models, schemas and migration dependencies.
2. Duplicate files are treated as duplicate evidence, not separate source versions.
3. Code excerpts are not assumed to constitute a complete repository. Missing imports, base models, earlier migrations, settings, router modules and runtime configuration must be located or implemented.
4. No provider integration is marked connected until a real provider handshake and credential validation exist.
5. A feature is marked implemented only after its backend, persistence, authorization, frontend flow and tests are connected.
